/**
 * dsh-plugin-skills-management - Browser half.
 *
 * One React app for every surface (settings section; the former sidebar
 *  full-page entry was retired — pair with dsh-settings-ui for room).
 * All interactive controls are host primitives (@deepseek-ai/dsh-client-ui-
 * primitives); all colors come from the ui-theme `--dsw-*` token layers so
 * light/dark follows the shell; all copy comes from the locale registry
 * (`zh`/`en`) so switches render live. No hardcoded colors, no ad-hoc copy.
 */

// React is a loader platform module. Under plain Node (contract tests) a
// minimal createElement/hook shim keeps the source loadable for assertions.
let __React = null
try { __React = require('react') } catch {}
if (!__React || typeof __React.createElement !== 'function') {
  __React = {
    createElement(type, props, ...kids) {
      return { type, props: props || {}, kids: kids.flat(9).filter(k => k !== null && k !== undefined && k !== false && k !== true && typeof k !== 'string' || true) }
    },
    useState(init) { const v = [typeof init === 'function' ? init() : init]; return [v[0], x => { v[0] = typeof x === 'function' ? x(v[0]) : x }] },
    useEffect() {}, useMemo(fn) { return fn() }, useRef(v = null) { return { current: v } },
  }
}
const { createElement: h, useState, useEffect, useMemo, useRef } = __React

// Platform module — always present in the loader's seeded require table.
// Under plain Node (tests) it is absent; a tagged-element shim keeps the
// tree structurally testable while every real surface ships primitives.
let P = null
try { P = require('@deepseek-ai/dsh-client-ui-primitives') } catch {}
let RDP = null
try { RDP = require('react-dom') } catch {}

// NOTE: no class components in this module. A `class X extends
// React.Component` error boundary defined here silently killed rendering in
// the plugin loader (components before it rendered, it never instantiated,
// zero errors) — render-time crashes are handled by the try/catch inside
// SkillsPage and recorded into globalThis.__skErrors instead.

/** Idempotent stylesheet injection — the overlay/tab/card classes are
 *  position-critical (.sk-overlay is position:fixed) so mounting without
 *  them renders the panel invisibly at the end of <body>. */
function ensureStyles() {
  if (typeof document === 'undefined' || document.getElementById('sk-styles')) return
  const holder = document.createElement('div')
  holder.id = 'sk-styles'
  holder.style.display = 'none'
  holder.innerHTML = STYLE
  document.head.appendChild(holder)
}

const prim = (name) => P && P[name]
  ? P[name]
  : function Shim(props) {
      const { children, text, ...rest } = props
      const tag = props.href ? 'a' : ['item', 'entry'].includes(props.__kind) ? 'div' : 'button'
      const el = document.createElement(tag === 'function' || typeof props.as === 'string' ? props.as : tag)
      return h(tag, { ...rest, 'data-p-shim': name }, children)
    }

// Sessions service (client runtime): opens the run's conversation in the
// real UI. Resolved through dynamic ctx.inject (ui-commands precedent);
// absence degrades the 打开对话 button to hidden.
let sessionsApi = null
const sessionsSvc = () => sessionsApi

// Composer services (inputTriggers + sessions) for the 技能 button plus
// the skills catalog face for the picker: the button opens
// the plugin's own searchable picker popover (the host slash menu filters
// only by a typed query, which a button click cannot provide); the pick is
// written into the draft via the session slot's standard `inputActions` face
// (`captureInsertion()` + `insertText()`, dsh 0.2.x+), falling back to the
// scoped `slash/input-insert-text` event on hosts that still hand the slot
// an `input` snapshot (≤0.1.x). Absence hides the button; nothing else
// depends on it.
// dsh 0.1.5+ moved the data plane off `connection.api` onto `ctx.remote.*`
// (subpath inject `remote.skills`); older cores still expose
// `connection.api.skills`. Prefer remote when present.
let composerScope = null
let remoteSkillsApi = null
let connectionApi = null

/**
 * Open one registered '/' source over a synthetic collapsed span appended at
 * the draft end (host toggleCommandMenu 同款调用形状；标准 kit 不暴露光标，
 * pick 依赖 span-CAS：点击后草稿若再变动则本次 pick 静默作废）。
 *
 * NOTE: the 技能 button no longer uses this — the host menu cannot offer
 * a search box, so the button opens SkillPicker instead. Kept for the
 * contract tests and as the documented toggleSource path.
 */
function openTriggerSource(scope, sessionId, input, sourceName) {
  const inputTriggers = scope && scope.inputTriggers
  const sessions = scope && scope.sessions
  if (!inputTriggers || !sessions) return false
  let actx
  try { actx = sessions.scope(sessionId) } catch { return false }
  if (actx === undefined || actx === null) return false
  let controller
  try { controller = inputTriggers.sessionOf(actx) } catch { return false }
  const draft = (input && input.draft) || ''
  const at = draft.length
  controller.toggleSource(sourceName, {
    trigger: '/',
    query: '',
    quoted: false,
    position: draft.trim() === '' ? 'leading' : 'inline',
    span: { start: at, end: at, draftRev: (input && input.draftRev) || 0 },
  })
  return true
}

/**
 * Insert `text` at the end of the session draft through the same scoped
 * event the host slash menu executes (`slash/input-insert-text`). The span
 * CAS uses the freshest input snapshot handed to the slot props — while the
 * picker popover is open the composer draft cannot move (focus is in the
 * picker), so the splice applies; a stale snapshot quietly no-ops, same as
 * the host menu's span-CAS.
 *
 * dsh 0.2.x fallback only: the slot's standard props dropped `input`, so on
 * new hosts `input` is undefined and this would splice with `draftRev: 0` —
 * rejected by the editor's span-CAS whenever the draft rev is past 0. The
 * primary path is `insertViaInputActions` (see below).
 */
function insertComposerText(scope, sessionId, input, text) {
  const sessions = scope && scope.sessions
  if (!sessions) return false
  const draft = (input && input.draft) || ''
  const at = draft.length
  const payload = { text, span: { start: at, end: at, draftRev: (input && input.draftRev) || 0 } }
  // dsh ≤0.1.6：sessions.scope(id) 直接返回会话的 cordis ctx。
  if (typeof sessions.scope === 'function') {
    let actx
    try { actx = sessions.scope(sessionId) } catch { return false }
    if (actx === undefined || actx === null || typeof actx.bail !== 'function') return false
    try {
      return actx.bail(actx, 'slash/input-insert-text', payload) === true
    } catch { return false }
  }
  // dsh 0.1.7+：scope() 移除，会话 ctx 经 using 的 reference.binding.ctx 取得
  // （ui-commands 的 PopupSelectController 同款）。using 异步打开会话后再回调，
  // 调用方本就不消费返回值（fire-and-forget + close + refocus）。
  if (typeof sessions.using === 'function') {
    try {
      const p = sessions.using(sessionId, { source: 'skillsComposer' }, (reference) => {
        const actx = reference && reference.binding && reference.binding.ctx
        if (actx && typeof actx.bail === 'function') {
          actx.bail(actx, 'slash/input-insert-text', payload)
        }
      })
      if (p && typeof p.catch === 'function') p.catch(() => {})
      return true
    } catch { return false }
  }
  return false
}

/**
 * dsh 0.2.x insertion channel: the `conversation.input.left` slot no longer
 * receives an `input` prop, so any span built from a prop snapshot carries
 * `draftRev: 0` and the editor's span-CAS (`span.draftRev !== this.rev`)
 * rejects it silently — pick closes the popover and nothing lands in the
 * draft. The slot instead receives the standard `inputActions` face; the
 * span must be captured at pick time (`captureInsertion()` returns a
 * revision-guarded copy of the live editor selection), not read from a
 * React prop, which always trails the editor revision.
 */
function insertViaInputActions(inputActions, text) {
  if (!inputActions
    || typeof inputActions.captureInsertion !== 'function'
    || typeof inputActions.insertText !== 'function') return false
  try {
    const span = inputActions.captureInsertion()
    if (!span || typeof span.draftRev !== 'number') return false
    return inputActions.insertText(text, span) === true
  } catch { return false }
}

/** Best-effort refocus of the composer textarea after the picker closes. */
function refocusComposer() {
  try {
    const card = document.querySelector('[data-composer-card]')
    const ta = card && card.querySelector('textarea')
    if (ta && typeof ta.focus === 'function') ta.focus()
  } catch {}
}

/** Picker popover list cap — beyond this the search input is the filter. */
const PICKER_ROW_CAP = 200

/** Skill catalog cache for the picker (ui-skill 同源：remote.skills / connection.api.skills). */
let skillCatalog = { sessionId: null, at: 0, rows: null }
const SKILL_CATALOG_TTL = 60_000

/**
 * Picker candidates from the host skill registry (the same list the `/`
 * skill source shows). Subagent sessions have no catalog (ui-skill 同款守卫);
 * a failed/absent catalog source rejects → the picker shows its empty state.
 *
 * `catalog` is `{ remoteSkills?, connection? }` from live inject, or a bare
 * legacy `connection` object (pre-0.1.5 tests / callers).
 * dsh 0.1.5+ (`remote.skills.list`): unwrapped `{ ok, value: { skills } }`.
 * Older cores (`connection.api.skills.list`): nested `{ result: { ok, value } }`.
 */
async function fetchSkillCandidates(catalog, sessions, sessionId) {
  try { if (sessions && typeof sessions.subagentAddress === 'function' && sessions.subagentAddress(sessionId) !== undefined) return [] } catch {}
  const now = Date.now()
  if (skillCatalog.rows !== null && skillCatalog.sessionId === sessionId && now - skillCatalog.at < SKILL_CATALOG_TTL) return skillCatalog.rows
  const bareLegacy = !!(catalog && typeof catalog === 'object' && !('remoteSkills' in catalog) && !('connection' in catalog))
  const remoteSkills = bareLegacy ? null : (catalog && catalog.remoteSkills)
  const connection = bareLegacy ? catalog : (catalog && catalog.connection)
  let list
  if (remoteSkills && typeof remoteSkills.list === 'function') {
    const res = await remoteSkills.list({ sessionId })
    if (!res || res.ok !== true) throw new Error('remote.skills.list failed')
    list = res.value && Array.isArray(res.value.skills) ? res.value.skills : []
  } else {
    const skills = connection && connection.api && connection.api.skills
    if (!skills || typeof skills.list !== 'function') throw new Error('skills list API unavailable')
    const res = await skills.list({ sessionId })
    const result = res && res.result
    if (!result || result.ok !== true) throw new Error('skill.list failed')
    list = result.value && Array.isArray(result.value.skills) ? result.value.skills : []
  }
  const rows = list.map((s) => ({ name: s.name, description: s.description || '', modelInvocable: s.modelInvocable !== false }))
  skillCatalog = { sessionId, at: now, rows }
  return rows
}

/**
 * 技能 picker：锚定在按钮上方、自带搜索框的候选浮层（portal 到 body）。
 * 宿主斜杠菜单靠「输入的 query」过滤，按钮打开的菜单没有输入载体——候选
 * 太多时无从筛选，所以浮层自带搜索框。键盘 ↑/↓/Enter/Esc，鼠标 hover+点击。
 */
function SkillPicker(props) {
  const t = props.t
  const [query, setQuery] = useState('')
  const [active, setActive] = useState(0)
  const inputRef = useRef(null)
  const listRef = useRef(null)
  useEffect(() => { try { if (inputRef.current) inputRef.current.focus() } catch {} }, [])
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape' && !(e.isComposing === true)) props.onClose() }
    try { document.addEventListener('keydown', onKey) } catch {}
    return () => { try { document.removeEventListener('keydown', onKey) } catch {} }
  }, [])
  const lower = query.trim().toLowerCase()
  const all = props.rows || []
  const filtered = lower === '' ? all : all.filter((r) => matchSkill(r, lower))
  const shown = filtered.slice(0, PICKER_ROW_CAP)
  useEffect(() => { setActive(0) }, [lower, props.rows])
  useEffect(() => {
    const list = listRef.current
    const el = list && list.children[active]
    if (el && typeof el.scrollIntoView === 'function') { try { el.scrollIntoView({ block: 'nearest' }) } catch {} }
  }, [active])
  const onKeyDown = (e) => {
    // IME 组词中的按键不触发选择（回车是选定拼音候选，不是 pick）
    if (e.nativeEvent && e.nativeEvent.isComposing === true) return
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive((i) => Math.min(i + 1, shown.length - 1)) }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive((i) => Math.max(i - 1, 0)) }
    else if (e.key === 'Enter') { e.preventDefault(); const row = shown[active]; if (row) props.onPick(row) }
  }
  const width = 400
  const winW = typeof window !== 'undefined' ? window.innerWidth : 800
  const winH = typeof window !== 'undefined' ? window.innerHeight : 600
  const left = Math.max(8, Math.min(props.anchor.left, winW - width - 8))
  const bottom = Math.max(8, winH - props.anchor.top + 6)
  return h('div', { className: 'sk-picker-backdrop', onMouseDown: (e) => { if (e.target === e.currentTarget) props.onClose() } },
    h('div', { className: 'sk-picker', style: { left, bottom, width }, role: 'dialog', 'aria-label': t('pickSkillTitle') },
      h('input', {
        ref: inputRef, className: 'sk-input sk-picker-input', value: query,
        placeholder: t('pickerSearch'), onChange: (e) => setQuery(e.target.value), onKeyDown,
      }),
      h('div', { className: 'sk-picker-list', ref: listRef, role: 'listbox' },
        props.rows === null
          ? h('div', { className: 'sk-picker-empty' }, t('pickerLoading'))
          : shown.length === 0
            ? h('div', { className: 'sk-picker-empty' }, t('emptySearch'))
            : shown.map((row, i) => h('button', {
                key: row.name, type: 'button', role: 'option', 'aria-selected': i === active,
                className: 'sk-picker-row', 'data-active': i === active,
                onMouseEnter: () => setActive(i),
                onMouseDown: (e) => { e.preventDefault(); props.onPick(row) },
              },
                h('span', { className: 'sk-picker-name' }, row.name),
                h('span', { className: 'sk-picker-desc' },
                  row.modelInvocable ? row.description : `${t('pickerUserOnly')} · ${row.description}`))))))
}

// ── Locale ───────────────────────────────────────────────────────────────

const NS = 'skillsManagement'

const ZH = {
  title: '技能市场',
  close: '关闭',
  tabExecutors: '已安装',
  tabMarket: '市场',
  tabSources: '来源',
  cardsHint: '选择一个智能体工具浏览它的技能，或一次查看全部',
  executorSettings: '执行器目录',
  executorSettingsHint: '管理本机各执行器的技能目录：遵循 ~/.xxx/skills 约定的目录会自动发现（Windows 为 %USERPROFILE%\\.xxx\\skills）；内置与自动发现的来源可改目录、可停用；也可新增自定义来源。保存后立即生效，无需重启。',
  execSourceBuiltin: '内置',
  execSourceAuto: '自动发现',
  execSourceCustom: '自定义',
  execDisabledTag: '已停用',
  execManagedTag: '由插件配置文件管理',
  execLockedTag: '锁定（本插件安装库）',
  execKeyLabel: '标识 (key)',
  execNameLabel: '显示名',
  execDirLabel: '技能目录',
  execEnabledLabel: '启用',
  execAdd: '新增执行器',
  execRemove: '删除',
  execRestore: '恢复默认',
  execRestoreConfirm: '确认恢复默认？将清空全部目录修改、停用状态与自定义执行器。',
  execKeyPlaceholder: '如 my-cli（小写字母、数字、连字符）',
  execNamePlaceholder: '显示名（可留空，默认同 key）',
  execDirPlaceholder: '如 ~/.my-cli/skills',
  execKeyInvalid: 'key 必须是小写字母/数字/连字符（kebab-case）',
  execKeyDup: 'key 与现有执行器重复',
  execDirRequired: '目录不能为空',
  marketCardsHint: '选择一个来源仓库浏览其技能，或一次查看全部',
  marketLoading: '正在加载市场目录…',
  marketSettings: '市场设置',
  syncNow: '立即同步',
  syncing: '同步中，可能需要一分钟…',
  syncDoneUpdated: '同步完成，市场已更新',
  syncDoneLatest: '已是最新版本',
  firstCloneDone: '首次克隆完成',
  repoUrlLabel: '仓库地址',
  branchLabel: '分支',
  lastSyncLabel: '上次同步',
  localCommitLabel: '本地版本',
  remoteCommitLabel: '远程版本',
  needsUpdateTag: '有更新',
  autoSyncLabel: '每天自动同步',
  syncOnStartupLabel: '启动时同步',
  publishMarketLabel: '市场技能进 / 菜单',
  publishMarketHint: '关掉后 / 菜单只剩已安装技能；市场页浏览/安装不受影响',
  save: '保存',
  saved: '设置已保存',
  gitMissing: '未检测到 git',
  repoDirLabel: '本地目录（同步内容存放处）',
  tokenLabel: '访问令牌（分享到社区/私有仓库需要）',
  tokenConfigured: '已配置',
  clearToken: '清除',
  shareBtn: '分享',
  shareTitle: '分享技能到官方仓库',
  shareHintPatMissing: '尚未配置访问令牌：先在 ⚙ 市场设置 中保存 GitCode 令牌，AI 才能以你的身份提交 PR。',
  shareHint: 'AI 将读取本机令牌，fork 官方仓库 → 建分支 → 提交该技能目录 → 创建 PR。确认或修改提示词后，复制到当前会话发送执行。',
  shareParamName: '技能名',
  shareParamDir: '本机目录',
  shareParamRemote: '目标路径',
  shareParamVersion: '版本',
  copyPrompt: '复制提示词',
  runBtn: '执行',
  openChat: '打开对话',
  running: '执行中…（可能需要几分钟）',
  runDone: '执行完成',
  runFailed: '执行失败',
  outputLabel: '执行输出',
  promptCopied: '提示词已复制，粘贴到输入框发送即可执行',
  repoMissing: '尚未克隆，点「立即同步」拉取',
  backSources: '← 按来源',
  backMarketCards: '← 来源卡片',
  allMarketTitle: '全部市场技能',
  browseAllMarket: '浏览全部市场技能',
  showMore: '显示更多（剩余 {n}）',
  browseAll: '浏览全部技能',
  refresh: '刷新',
  backCards: '← 智能体工具卡片',
  backExecutors: '← 已安装',
  backAll: '← 全部技能',
  searchAll: '搜索全部技能…',
  filterWithin: '在 {label} 内筛选…',
  pickSource: '全部智能体工具',
  loadingCatalogs: '正在加载全部智能体工具目录…',
  scanning: '正在扫描 {label}…',
  skillsSuffix: '个技能',
  noExecutors: '本机未发现任何智能体工具目录',
  dirMissingTitle: '{label}：目录不存在',
  dirMissingHint: '预期位置 {dir}',
  notFoundGroup: '本机不存在的来源（{n}）',
  dirNotPresent: '目录不存在',
  emptySearch: '没有匹配的技能',
  emptySkillsIn: '{label} 中还没有技能',
  installedTag: '已装',
  readOnlyTag: '只读',
  toDsh: '安装',
  deleteBtn: '删除',
  detail: '详情',
  filesCount: '{n} 个文件',
  totalSize: '共 {size}',
  copy: '复制内容',
  copied: '已复制到剪贴板',
  mdCodeLabel: '代码',
  mdCodeWrap: '自动换行',
  mdCodeUnwrap: '取消换行',
  mdFootnotes: '脚注',
  installFrom: '从 {label} 安装',
  cancel: '取消',
  installFromMarket: '从市场安装 {name}？',
  deleteTitle: '删除技能',
  deleteConfirm: '即将从「{where}」删除技能「{name}」，删除后移入回收站，可随时恢复。',
  tabTrash: '回收站',
  trashHint: '删除的技能暂存于此，可恢复到原位置或彻底删除。',
  trashRetentionDays: '保留 {n} 天，到期自动清理',
  trashKeepForever: '永久保留，不自动清理',
  trashEmpty: '回收站是空的',
  trashDisabled: '回收站已被插件配置（trash: false）停用，删除直接生效、不可恢复。',
  trashNoRestoreTag: '元数据缺失，无法恢复',
  trashFromLabel: '来源',
  trashDeletedAtLabel: '删除时间',
  restoreBtn: '恢复',
  deleteForeverBtn: '彻底删除',
  emptyTrashBtn: '清空回收站',
  restoreConfirm: '将「{name}」恢复到原位置 {dir}？',
  deleteForeverConfirm: '彻底删除「{name}」？此操作不可恢复。',
  emptyTrashConfirm: '清空回收站？{n} 个回收项将被永久删除，此操作不可恢复。',
  restoredToast: '已恢复到原位置',
  deletedForeverToast: '已彻底删除',
  emptiedTrashToast: '回收站已清空',
  movedToTrash: '已移入回收站',
  migrateBtn: '迁至共享池',
  migrateTitle: '迁至 Agents 共享池',
  migrateConfirm: '将把「{name}」移动到 {pool}，并在原位置留下链接；各来源仍可正常使用该技能。',
  migratedToast: '已迁至共享池，原位置已留链接',
  linkedByTitle: '链接来源：{names}',
  linkedByCount: '链接 {n} 个',
  linkedByDialogTitle: '链接来源（{n}）',
  linkedByDialogHint: '这些执行器的 skills 目录下有指向该技能的链接。勾选后可批量删除链接（移入回收站），池中的技能本体不受影响。',
  deleteSelectedBtn: '删除选中（{n}）',
  deletedLinksToast: '已删除 {n} 个链接（已移入回收站）',
  selectAllBtn: '全选',
  invertSelectionBtn: '反选',
  installMoreBtn: '更多',
  installToTitle: '安装技能',
  installToHint: '勾选「{name}」要装到的位置：默认 DSH 技能库，「更多执行器」可装到其它工具。选择会被记住，下次打开沿用。目标已有同名技能会标注并保留。',
  moreExecutorsBtn: '更多执行器 ▾',
  installToBtn: '安装（{n}）',
  installedToToast: '已安装到 {n} 个执行器',
  noInstallTargets: '没有可用的目标执行器',
  whereDsh: 'DSH 技能库',
  operationFailed: '操作失败',
  preview: '文件预览',
  content: '内容',
  activeInDsh: '已在 DSH 生效',
  invocationToggle: '模型可调用',
  hiddenTag: '已隐藏',
  hideAction: '隐藏',
  restoreAction: '恢复可见',
  modelVisibleTag: '模型可见',
  detailHideAction: '在模型目录隐藏',
  invocationOn: '模型可见',
  invocationOff: '已从模型目录隐藏',
  invocationHint: '关闭后技能保留在库里，但不再注入对话目录（skill 工具也调不到）',
  pathLabel: '路径',
  meTag: '本机',
  pickSkill: '技能',
  pickSkillTitle: '选择一个技能，其内容将注入本条消息',
  pickerSearch: '搜索技能名称或描述…',
  pickerLoading: '正在加载技能目录…',
  pickerUserOnly: '仅用户',
  usageStat: '≈{tokens} token · {chars} 字符',
  usageCharsOnly: '{chars} 字符',
  usageHint: '按「名称+描述」全文估算的注入开销（cl100k_base 词表，DeepSeek 实际分词略有差异，适合横向比较）',
  usageMetaLabel: '≈注入开销',
  sortLabel: '排序',
  sortDefault: '默认排序',
  sortTokensDesc: 'token 高→低',
  sortTokensAsc: 'token 低→高',
  sortCharsDesc: '字符 多→少',
  linkTag: '链接',
  linkTargetLabel: '链接目标',
}

const EN = {
  title: 'Skills Market',
  close: 'Close',
  tabExecutors: 'Installed',
  tabMarket: 'Market',
  tabSources: 'Sources',
  cardsHint: 'Pick an agent tool to browse its skills, or view everything at once',
  executorSettings: 'Executor dirs',
  executorSettingsHint: 'Manage the skill directories of on-machine executors: any ~/.xxx/skills directory is auto-discovered (on Windows: %USERPROFILE%\\.xxx\\skills); built-in and auto-discovered sources can be redirected or disabled; custom sources can be added. Changes apply immediately, no restart.',
  execSourceBuiltin: 'built-in',
  execSourceAuto: 'auto-discovered',
  execSourceCustom: 'custom',
  execDisabledTag: 'disabled',
  execManagedTag: 'managed by plugin config',
  execLockedTag: 'locked (this plugin\'s library)',
  execKeyLabel: 'Key',
  execNameLabel: 'Display name',
  execDirLabel: 'Skills dir',
  execEnabledLabel: 'Enabled',
  execAdd: 'Add executor',
  execRemove: 'Remove',
  execRestore: 'Restore defaults',
  execRestoreConfirm: 'Restore defaults? This clears all dir overrides, disabled flags and custom executors.',
  execKeyPlaceholder: 'e.g. my-cli (lowercase letters, digits, hyphens)',
  execNamePlaceholder: 'Display name (optional, defaults to key)',
  execDirPlaceholder: 'e.g. ~/.my-cli/skills',
  execKeyInvalid: 'key must be kebab-case (a-z 0-9 -)',
  execKeyDup: 'key conflicts with an existing executor',
  execDirRequired: 'directory is required',
  marketCardsHint: 'Pick a source repo to browse its skills, or view everything at once',
  marketLoading: 'Loading market catalog…',
  marketSettings: 'Market Settings',
  syncNow: 'Sync now',
  syncing: 'Syncing, may take a minute…',
  syncDoneUpdated: 'Synced, market updated',
  syncDoneLatest: 'Already up to date',
  firstCloneDone: 'Initial clone complete',
  repoUrlLabel: 'Repository URL',
  branchLabel: 'Branch',
  lastSyncLabel: 'Last sync',
  localCommitLabel: 'Local commit',
  remoteCommitLabel: 'Remote commit',
  needsUpdateTag: 'Updates available',
  autoSyncLabel: 'Auto sync daily',
  syncOnStartupLabel: 'Sync on startup',
  publishMarketLabel: 'Market skills in / menu',
  publishMarketHint: 'When off, / only lists installed skills; market browse/install still works',
  save: 'Save',
  saved: 'Settings saved',
  gitMissing: 'git not found',
  repoDirLabel: 'Local directory (sync target)',
  tokenLabel: 'Access token (community sharing / private repos)',
  tokenConfigured: 'configured',
  clearToken: 'Clear',
  shareBtn: 'Share',
  shareTitle: 'Share skill to the official repo',
  shareHintPatMissing: 'No access token configured — save a GitCode token in ⚙ Market Settings first so the AI can open the PR as you.',
  shareHint: 'The AI will read the local token, fork the official repo, create a branch, commit this skill directory and open a PR. Review or edit the prompt, copy it into the current session and send.',
  shareParamName: 'Skill',
  shareParamDir: 'Local directory',
  shareParamRemote: 'Remote path',
  shareParamVersion: 'Version',
  copyPrompt: 'Copy prompt',
  runBtn: 'Run',
  openChat: 'Open chat',
  running: 'Running… (may take minutes)',
  runDone: 'Run complete',
  runFailed: 'Run failed',
  outputLabel: 'Output',
  promptCopied: 'Prompt copied — paste into the composer and send',
  repoMissing: 'Not cloned yet — hit Sync now',
  backSources: '← By source',
  backMarketCards: '← Source cards',
  allMarketTitle: 'All Market Skills',
  browseAllMarket: 'Browse all market skills',
  showMore: 'Show more ({n} left)',
  browseAll: 'Browse all skills',
  refresh: 'Refresh',
  backCards: '← Agent tool cards',
  backExecutors: '← Installed',
  backAll: '← All skills',
  searchAll: 'Search all skills…',
  filterWithin: 'Filter within {label}…',
  pickSource: 'All agent tools',
  loadingCatalogs: 'Loading all agent tool catalogs…',
  scanning: 'Scanning {label}…',
  skillsSuffix: 'skills',
  noExecutors: 'No agent tool directories found on this machine',
  dirMissingTitle: '{label}: directory not found',
  dirMissingHint: 'Expected skills at {dir}',
  notFoundGroup: 'Not found on this machine ({n})',
  dirNotPresent: 'directory not present',
  emptySearch: 'No matching skills',
  emptySkillsIn: 'No skills in {label}',
  installedTag: 'Installed',
  readOnlyTag: 'read-only',
  toDsh: 'Install',
  deleteBtn: 'Delete',
  detail: 'Detail',
  filesCount: '{n} files',
  totalSize: '{size}',
  copy: 'Copy content',
  copied: 'Copied to clipboard',
  mdCodeLabel: 'Code',
  mdCodeWrap: 'Wrap lines',
  mdCodeUnwrap: 'No wrap',
  mdFootnotes: 'Footnotes',
  installFrom: 'Install from {label}',
  cancel: 'Cancel',
  installFromMarket: 'Install {name} from market?',
  deleteTitle: 'Delete skill',
  deleteConfirm: 'You are about to delete "{name}" from {where}. It will be moved to the trash and can be restored.',
  tabTrash: 'Trash',
  trashHint: 'Deleted skills are kept here — restore them to their original location or delete them forever.',
  trashRetentionDays: 'Kept for {n} days, then purged automatically',
  trashKeepForever: 'Kept forever, never auto-purged',
  trashEmpty: 'Trash is empty',
  trashDisabled: 'Trash is disabled by plugin config (trash: false); deletes take effect immediately and cannot be undone.',
  trashNoRestoreTag: 'metadata missing, cannot restore',
  trashFromLabel: 'Source',
  trashDeletedAtLabel: 'Deleted',
  restoreBtn: 'Restore',
  deleteForeverBtn: 'Delete forever',
  emptyTrashBtn: 'Empty trash',
  restoreConfirm: 'Restore "{name}" to its original location {dir}?',
  deleteForeverConfirm: 'Permanently delete "{name}"? This cannot be undone.',
  emptyTrashConfirm: 'Empty the trash? {n} entries will be permanently deleted. This cannot be undone.',
  restoredToast: 'Restored to its original location',
  deletedForeverToast: 'Permanently deleted',
  emptiedTrashToast: 'Trash emptied',
  movedToTrash: 'Moved to trash',
  migrateBtn: 'Move to pool',
  migrateTitle: 'Move to Agents pool',
  migrateConfirm: '"{name}" will be moved to {pool}, with a link left at the original location. Every source keeps working with it.',
  migratedToast: 'Moved to the pool; link left in place',
  linkedByTitle: 'Linked by: {names}',
  linkedByCount: '{n} linked by',
  linkedByDialogTitle: 'Linked by ({n})',
  linkedByDialogHint: 'These executors link to this skill from their skills directories. Select links to delete them (moved to trash); the pooled skill itself stays untouched.',
  deleteSelectedBtn: 'Delete selected ({n})',
  deletedLinksToast: 'Deleted {n} link(s) — moved to trash',
  selectAllBtn: 'Select all',
  invertSelectionBtn: 'Invert',
  installMoreBtn: 'More',
  installToTitle: 'Install skill',
  installToHint: 'Pick where "{name}" goes: the DSH library by default, or expand More executors to copy it into other tools. Your selection is remembered for next time. Targets already holding a same-named skill are marked and kept.',
  moreExecutorsBtn: 'More executors ▾',
  installToBtn: 'Install ({n})',
  installedToToast: 'Installed to {n} executor(s)',
  noInstallTargets: 'No target executors available',
  whereDsh: 'the DSH library',
  operationFailed: 'Operation failed',
  preview: 'File preview',
  content: 'Content',
  activeInDsh: 'active in DSH',
  invocationToggle: 'Model-invocable',
  hiddenTag: 'hidden',
  hideAction: 'Hide',
  restoreAction: 'Restore',
  modelVisibleTag: 'model-visible',
  detailHideAction: 'Hide from model catalog',
  invocationOn: 'model-visible',
  invocationOff: 'hidden from model catalog',
  invocationHint: 'When off, the skill stays in the library but is not injected into conversation catalogs',
  pathLabel: 'Path',
  meTag: 'me',
  pickSkill: 'Skill',
  pickSkillTitle: 'Pick a skill; its content is injected into this message',
  pickerSearch: 'Search skills by name or description…',
  pickerLoading: 'Loading skill catalog…',
  pickerUserOnly: 'user-only',
  usageStat: '≈{tokens} tokens · {chars} chars',
  usageCharsOnly: '{chars} chars',
  usageHint: 'Estimated injection cost of the full name+description (cl100k_base; DeepSeek tokenizes slightly differently — for comparison, not billing)',
  usageMetaLabel: '≈Injection cost',
  sortLabel: 'Sort',
  sortDefault: 'Default order',
  sortTokensDesc: 'tokens high→low',
  sortTokensAsc: 'tokens low→high',
  sortCharsDesc: 'chars high→low',
  linkTag: 'link',
  linkTargetLabel: 'Link target',
}

// ── Pure helpers ────────────────────────────────────────────────────────

/** ntd ActionButton 同款 {{key}} 替换:split/join 规避正则元字符 */
const SHARE_PROMPT_ZH = [
  '请把本地技能「{{skillName}}」{{version}}打包提交到 GitCode 官方仓库，作为一个 PR 供维护者审核。',
  '',
  '## 关键信息',
  '- 技能目录：{{resourceDir}}（~ 表示当前用户家目录，执行前先展开为绝对路径）',
  '- 官方仓库：weibaohui/ntd-resource（GitCode，API base = https://api.gitcode.com）',
  '- PAT 位置：{{settingsFile}} 中 skills-management.market 段的 token 字段（由技能市场设置面板保存）。',
  '',
  '## 执行步骤（严格按顺序）',
  '1. 读取 PAT：读取 {{settingsFile}}，定位 skills-management.market 段下的 token 字段。token 是敏感凭据，读取后不要把明文打印到输出、日志或最终结果里。',
  '2. 展开技能目录为绝对路径，遍历该目录，收集每个文件的「相对该目录的路径」与内容；跳过 .downloaded_at、.clawhub、.git 三类同步元数据。',
  '3. 把第 1 步读到的 token 作为 HTTP 认证令牌，附加到下面每个 GitCode API 请求的认证头里（bearer 认证方式），不要写成占位符：',
  '   a. 验证用户：`GET https://api.gitcode.com/api/v5/user`，拿到返回的 login 字段——这是 token 真实所属的账号，后续所有 URL 里的 {owner} 一律用它。',
  '   b. fork：`POST https://api.gitcode.com/api/v5/repos/weibaohui/ntd-resource/forks`；若返回 409/422 表示已 fork，视为成功。',
  '   c. 建分支：`POST https://api.gitcode.com/api/v5/repos/{步骤 a 的 login}/ntd-resource/branches`，JSON body 为 {"branch_name":"contrib/{{skillName}}-<unix 时间戳>","refs":"main"}。',
  '   d. 写文件：对第 2 步收集的每个文件，`POST https://api.gitcode.com/api/v5/repos/{步骤 a 的 login}/ntd-resource/contents/{{remotePath}}<该文件的相对路径>`。**必须**用这个远端路径前缀，不能写到仓库根目录。表单字段 content=<文件字节的 base64>、message="贡献技能 {{skillName}} {{version}}"、branch=<步骤 c 的分支名>。',
  '   e. 创建 PR：`POST https://api.gitcode.com/api/v5/repos/weibaohui/ntd-resource/pulls`，JSON body 为 {"title":"[技能] {{skillName}} {{version}}","body":"技能目录 {{resourceDir}} 的文件清单与用途简介","head":"{步骤 a 的 login}:{branch}","base":"main"}。',
  '4. 完成后，最终输出 PR 的网页链接（响应里的 web_url 字段）。',
  '',
  '## 注意',
  '- token 是敏感凭据，任何输出里都不要回显其明文。',
  '- 如果任一步骤失败，先检查错误信息，不要盲目重试；若 token 失效，提示用户到技能市场的 ⚙ 设置面板重新填写。',
  '- 全程与最终汇报都使用中文。',
].join('\n')

// API 基址随页面走：子路径反代（如 https://host/app/dsh/）下，绝对路径 /skills-management/api
// 会打到站点根而 404。与宿主官方客户端一致，用 document.baseURI 推导（dsh-sync#14 同款）。
const API = (() => {
  try {
    const base = (typeof document !== 'undefined' && document.baseURI) || (typeof location !== 'undefined' ? location.href : '/')
    return new URL('skills-management/api', new URL('.', base)).pathname.replace(/\/+$/, '')
  } catch { return '/skills-management/api' }
})()

function formatSize(bytes) {
  if (!Number.isFinite(bytes) || bytes < 0) return '-'
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
}

function formatTime(iso) {
  if (!iso) return '-'
  try {
    const days = Math.floor((Date.now() - new Date(iso).getTime()) / 86400000)
    if (days > 30) return new Date(iso).toLocaleDateString()
    if (days > 0) return days + 'd'
    const hours = Math.floor((Date.now() - new Date(iso).getTime()) / 3600000)
    if (hours > 0) return hours + 'h'
    const minutes = Math.floor((Date.now() - new Date(iso).getTime()) / 60000)
    if (minutes > 0) return minutes + 'm'
    return 'now'
  } catch { return '-' }
}

/** 头像底色：名字缺失或非字符串时退化为固定色，绝不在渲染期抛错
 *  （渲染期 ANY throw 会被 SkillsPage 的 try/catch 换成空面板，见文首注释）。 */
function gradient(name) {
  const src = String(name || '')
  let hash = 0
  for (let i = 0; i < src.length; i++) hash = ((hash << 5) - hash + src.charCodeAt(i)) | 0
  const h1 = Math.abs(hash) % 360
  return `linear-gradient(135deg, hsl(${h1},55%,55%), hsl(${(h1 + 40) % 360},45%,45%))`
}

const shortName = (name) => {
  const src = String(name || '')
  return src.includes('/') ? src.split('/').slice(1).join('/') : src
}

/** Shared predicate for skill filtering (name / description / keywords). */
function matchSkill(s, lower) {
  return (s.name || '').toLowerCase().includes(lower) ||
    (s.description || '').toLowerCase().includes(lower) ||
    (s.keywords || []).some(k => String(k).toLowerCase().includes(lower))
}

/** 「已在本机 DSH 库」判定。市场列表行带 `installed`（服务端用已装技能名集合算出），
 *  详情接口带 `isInstalled`；两个面都认，卡片/详情才不会漏标。 */
function isInstalledRow(s) {
  return s?.installed === true || s?.isInstalled === true
}

/** 就地翻转市场行的 installed 位（保持原数组不命中时引用不变，便于 React 跳过重渲染）。
 *  安装/删除只影响一行，没必要为它重走一遍 6k+ 的全市场扫描（GET / 约 2.3s）。 */
function patchMarketInstalled(market, name, on) {
  if (!Array.isArray(market) || !name) return market
  const target = String(name)
  let hit = false
  const next = market.map(s => {
    // 市场行同时带 relPath（name）与末段（shortName），两个都比对
    if (s.name === target || s.shortName === target) { hit = true; return { ...s, installed: on } }
    return s
  })
  return hit ? next : market
}

/** 注入开销一行文案：token 在（宿主装了词表）→「≈N token · M 字符」，
 *  降级时只剩字符数；两者都缺（旧响应）→ null 不渲染。 */
function usageText(s, t) {
  if (typeof s.tokens === 'number') return t('usageStat', { tokens: s.tokens, chars: s.chars ?? (s.description || '').length })
  if (typeof s.chars === 'number') return t('usageCharsOnly', { chars: s.chars })
  return null
}

/** MarkdownText 的 labels（宿主 .d.ts 里是必填）：围栏代码块的复制/换行
 *  工具条与脚注小节标题。不传时宿主渲染到第一个 ``` 围栏就在
 *  labels.code.copyLabel 上读 undefined 抛 TypeError，宿主错误边界随即把
 *  整个 settings.section 卸载——详情弹窗一点就白屏的根因。宿主要求引用
 *  稳定（按 locale 记忆化），调用方以 useMemo 包住、依赖取具体文案，
 *  语言切换时对象自然换新。 */
function markdownLabels(t) {
  return {
    code: {
      copyLabel: t('copy'),
      copiedLabel: t('copied'),
      toolbarLabels: {
        codeLabel: t('mdCodeLabel'),
        wrapLabel: t('mdCodeWrap'),
        unwrapLabel: t('mdCodeUnwrap'),
      },
    },
    footnotes: t('mdFootnotes'),
  }
}

/** 卡片排序：缺 token/chars 的行（预热未完成或降级模式）永远沉底，
 *  其余按所选指标升/降序。keyFn 供 {row, s} 包装数组取卡片行。 */
function sortSkills(rows, sortBy, keyFn = (s) => s) {
  if (!sortBy || sortBy === 'default') return rows
  const pick = sortBy === 'chars' ? (s) => keyFn(s).chars : (s) => keyFn(s).tokens
  const asc = sortBy === 'tokensAsc'
  return [...rows].sort((a, b) => {
    const va = pick(a), vb = pick(b)
    if (va === vb) return 0
    if (va === undefined || va === null) return 1
    if (vb === undefined || vb === null) return -1
    return asc ? va - vb : vb - va
  })
}

/** 排序下拉（原生 select：排序是低频操作，不值得自绘 popover）。 */
function SortSelect({ value, onChange, t }) {
  return h('select', { value, onChange: e => onChange(e.target.value), style: selectStyle(), title: t('sortLabel'), 'aria-label': t('sortLabel') },
    h('option', { value: 'default' }, t('sortDefault')),
    h('option', { value: 'tokens' }, t('sortTokensDesc')),
    h('option', { value: 'tokensAsc' }, t('sortTokensAsc')),
    h('option', { value: 'chars' }, t('sortCharsDesc')))
}

// ── Token-based stylesheet (light/dark adaptive by construction) ────────

const STYLE = `<style>
.sk-page{position:relative;display:flex;flex-direction:column;gap:14px;color:var(--dsw-alias-label-primary);font-family:var(--dsw-font-family);font-size:var(--dsw-font-sm-14,14px)}
.sk-overlay{position:fixed;inset:0;z-index:2147483000;background:var(--dsw-alias-bg-base);overflow:auto;padding:20px 26px}
.sk-tabs{display:flex;gap:6px;border-bottom:1px solid var(--dsw-alias-border-l2);padding-bottom:10px}
.sk-toolbar{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.sk-body{display:flex;flex-direction:column;gap:14px}
.sk-inv-toggle{display:inline-flex;gap:8px;align-items:center}
.spacer{flex:1}
.sk-hint{color:var(--dsw-alias-label-secondary)}
.sk-dir{color:var(--dsw-alias-label-tertiary);font-size:var(--dsw-font-xs-13,12px)}
.sk-tag{display:inline-flex;align-items:center;padding:2px 9px;border-radius:999px;background:var(--dsw-alias-bg-layer-2);border:1px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-label-secondary);font-size:11.5px}
.sk-tag.accent{color:var(--dsw-alias-state-business-primary);border-color:var(--dsw-alias-state-business-primary)}
.sk-tag.danger{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary)}
.sk-tag.ok{color:var(--dsw-alias-state-success-primary);border-color:var(--dsw-alias-state-success-primary)}
.sk-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:14px}
.sk-src{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:14px}
	.sk-card{display:flex;flex-direction:column;gap:10px;padding:16px;border-radius:12px;border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-layer-1);cursor:pointer;text-align:left}
	.sk-card:hover{border-color:var(--dsw-alias-border-l3);background:var(--dsw-alias-interactive-bg-hover)}
	.sk-card.link{border-style:dashed;border-color:var(--dsw-alias-border-l3);background:linear-gradient(var(--dsw-alias-interactive-bg-active),var(--dsw-alias-interactive-bg-active)),var(--dsw-alias-bg-layer-1)}
	.sk-card.link:hover{border-color:var(--dsw-alias-border-l3);background:linear-gradient(var(--dsw-alias-interactive-bg-active),var(--dsw-alias-interactive-bg-active)),var(--dsw-alias-bg-layer-1)}
	.sk-card.missing{opacity:.5;cursor:default}
.sk-avatar.sq{border-radius:12px}
.sk-avatar{width:42px;height:42px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-weight:700;color:var(--dsw-alias-label-primary-inverted,#fff);font-size:17px;flex:none}
.sk-title{font-weight:600;word-break:break-all}
.sk-desc{color:var(--dsw-alias-label-secondary);font-size:13px;line-height:1.5;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.sk-stats{color:var(--dsw-alias-label-secondary);font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sk-foot{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:auto;padding-top:10px;border-top:1px solid var(--dsw-alias-border-l1);flex-wrap:wrap}
.sk-chips{display:flex;gap:6px;flex-wrap:wrap;min-width:0}
.sk-rowbtns{display:flex;gap:6px;flex-wrap:wrap}
.sk-head{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.sk-countline{display:flex;align-items:baseline;gap:2px;color:var(--dsw-alias-label-secondary);font-size:13px}
.sk-count{font-size:26px;font-weight:700;color:var(--dsw-alias-brand-primary,var(--dsw-alias-state-business-primary))}
.sk-count.none{color:var(--dsw-alias-label-dimmed,var(--dsw-alias-label-tertiary))}
.sk-empty{border:1px dashed var(--dsw-alias-border-l2);border-radius:12px;padding:44px 20px;text-align:center;color:var(--dsw-alias-label-secondary)}
.sk-loading{padding:48px;text-align:center;color:var(--dsw-alias-label-secondary)}
.sk-spin{width:30px;height:30px;margin:0 auto 10px;border-radius:50%;border:3px solid var(--dsw-alias-border-l2);border-top-color:var(--dsw-alias-brand-primary,var(--dsw-alias-state-business-primary));animation:skspin .7s linear infinite}
@keyframes skspin{to{transform:rotate(360deg)}}
.sk-list{display:flex;flex-direction:column;gap:8px}
.sk-list .sk-card{flex-direction:row;align-items:center;padding:12px 14px}
.sk-filewrap{display:flex;gap:14px;min-height:300px}
.sk-files{flex:0 0 230px;max-height:430px;overflow:auto;border:1px solid var(--dsw-alias-border-l1);border-radius:10px;background:var(--dsw-alias-bg-layer-1)}
.sk-file{display:flex;align-items:center;gap:8px;width:100%;padding:7px 11px;font-size:12.5px;border:none;background:transparent;color:var(--dsw-alias-label-primary);cursor:pointer;text-align:left}
.sk-file:hover{background:var(--dsw-alias-interactive-bg-hover)}
.sk-file.on{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-state-business-primary)}
.sk-preview{flex:1;max-height:430px;overflow:auto;border:1px solid var(--dsw-alias-border-l1);border-radius:10px;background:var(--dsw-alias-bg-layer-1);padding:14px}
.sk-meta{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}
.sk-meta div{background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l1);border-radius:10px;padding:10px 12px;min-width:0}
.sk-dlg-backdrop{position:fixed;inset:0;z-index:30;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;padding:24px}
.sk-dlg{background:var(--dsw-alias-bg-layer-2);border:1px solid var(--dsw-alias-border-l2);border-radius:14px;min-width:340px;max-width:640px;max-height:82vh;overflow:auto;padding:18px;box-shadow:var(--dsw-shadow-lv3);color:var(--dsw-alias-label-primary);font-family:var(--dsw-font-family)}
.sk-dlg h3{margin:0 0 12px;font-size:15px}
.sk-dlg-foot{display:flex;gap:8px;justify-content:flex-end;margin-top:14px}
.sk-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:32px;padding:6px 16px;border-radius:8px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);font-size:13px;font-weight:500;cursor:pointer;font-family:var(--dsw-font-family);white-space:nowrap}
.sk-btn:hover{border-color:var(--dsw-alias-border-l3);background:var(--dsw-alias-interactive-bg-hover)}
.sk-btn:disabled{opacity:.5;cursor:not-allowed}
.sk-btn-primary{background:var(--dsw-alias-state-business-primary);border-color:transparent;color:var(--dsw-alias-label-primary-inverted,#fff)}
.sk-btn-primary:hover{filter:brightness(1.08);background:var(--dsw-alias-state-business-primary)}
.sk-btn-sm{min-height:28px;padding:4px 12px;font-size:12.5px;min-width:64px}
.sk-input{min-height:32px;padding:6px 12px;border-radius:8px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);font-size:13px;font-family:var(--dsw-font-family);outline:none}
.sk-input:focus{border-color:var(--dsw-alias-state-business-primary)}
.sk-input::placeholder{color:var(--dsw-alias-label-tertiary)}
.sk-toast{position:fixed;left:50%;bottom:28px;transform:translateX(-50%);z-index:40;background:var(--dsw-alias-bg-layer-3);color:var(--dsw-alias-label-primary);border:1px solid var(--dsw-alias-border-l2);border-radius:999px;padding:8px 18px;font-size:13px;box-shadow:var(--dsw-shadow-lv2)}
.sk-menu{position:absolute;top:100%;left:0;margin-top:4px;min-width:220px;max-height:340px;overflow:auto;background:var(--dsw-alias-bg-layer-3);border:1px solid var(--dsw-alias-border-l2);border-radius:10px;box-shadow:var(--dsw-shadow-lv2,var(--dsw-shadow-lv1));z-index:2147483600;padding:4px}
.sk-menu-item{padding:8px 12px;border-radius:8px;cursor:pointer;color:var(--dsw-alias-label-primary);font-size:13px;white-space:nowrap}
.sk-menu-item:hover{background:var(--dsw-alias-interactive-bg-hover)}
.sk-menu-item.on{color:var(--dsw-alias-state-business-primary);font-weight:500}
.sk-tabpill{background:transparent;border:none;color:var(--dsw-alias-label-secondary);font-family:var(--dsw-font-family)}
.sk-chip{display:inline-flex;align-items:center;gap:5px;height:26px;padding:0 7px;border-radius:8px;border:none;background:transparent;color:var(--dsw-alias-label-secondary);font-family:var(--dsw-font-family);font-size:12px;cursor:pointer;white-space:nowrap}
.sk-chip:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
.sk-chip svg{width:13px;height:13px;flex:none;display:block}
.sk-picker-backdrop{position:fixed;inset:0;z-index:2147483200}
.sk-picker{position:fixed;z-index:2147483201;width:400px;max-width:92vw;max-height:360px;display:flex;flex-direction:column;gap:4px;padding:6px;background:var(--dsw-specific-menu);backdrop-filter:var(--dsw-menu-backdrop-filter,blur(20px) saturate(150%));-webkit-backdrop-filter:var(--dsw-menu-backdrop-filter,blur(20px) saturate(150%));border:1px solid var(--dsw-alias-border-inverted);border-radius:12px;box-shadow:var(--dsw-shadow-lv3)}
.sk-picker-input{flex:none;box-sizing:border-box;width:100%}
.sk-picker-list{display:flex;flex-direction:column;min-height:40px;overflow-y:auto}
.sk-picker-row{display:flex;align-items:center;gap:8px;width:100%;min-height:36px;padding:6px 10px;border:0;border-radius:8px;background:transparent;color:var(--dsw-alias-label-primary);text-align:left;cursor:pointer;font-family:var(--dsw-font-family);font-size:13px}
.sk-picker-row[data-active="true"]{background:var(--dsw-alias-interactive-bg-hover)}
.sk-picker-name{flex:none;max-width:45%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500}
.sk-picker-desc{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--dsw-alias-label-tertiary);font-size:12px}
.sk-picker-empty{padding:12px 10px;text-align:center;color:var(--dsw-alias-label-dimmed);font-size:13px}
</style>`

// ── Fetch layer ─────────────────────────────────────────────────────────

async function getJson(url) {
  const r = await fetch(url)
  if (!r.ok) throw new Error('HTTP ' + r.status)
  return r.json()
}

// ── Small building blocks ────────────────────────────────────────────────

// 安装目标记忆（localStorage）：安装对话框下次打开时沿用上次的勾选
const INSTALL_TARGETS_KEY = 'skills-management:install-targets'
function loadInstallTargets() {
  try {
    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(INSTALL_TARGETS_KEY) : null
    const parsed = raw ? JSON.parse(raw) : null
    return Array.isArray(parsed) ? parsed.filter(x => typeof x === 'string') : []
  } catch { return [] }
}
function saveInstallTargets(keys) {
  try { if (typeof localStorage !== 'undefined') localStorage.setItem(INSTALL_TARGETS_KEY, JSON.stringify(keys)) } catch {}
}

const Tag = ({ tone, children, ...rest }) =>
  h('span', { className: 'sk-tag' + (tone ? ' ' + tone : ''), ...rest }, children)

const Spinner = ({ label }) =>
  h('div', { className: 'sk-loading' },
    h('div', { className: 'sk-spin' }),
    h('div', null, label))

const Empty = ({ children }) => h('div', { className: 'sk-empty' }, children)

function Avatar({ name, square, size }) {
  // 渲染期必须 total：linkedBy 等数据在宿主/插件版本错配时可能是旧形状
  // （字符串而非 {key,name}），name 可能落为 undefined——绝不能在这里抛
  const initial = (String(name || '?')[0] || '?').toUpperCase()
  const sizing = size ? { width: size, height: size, fontSize: Math.round(size * 0.42) } : {}
  return h('div', { className: 'sk-avatar' + (square ? ' sq' : ''),
      style: { background: gradient(name), ...sizing } },
    initial)
}

/** Executor dropdown: self-contained popover (host primitives expose no Menu). */
function SourceFilter({ rows, value, onChange, t }) {
  const [open, setOpen] = useState(false)
  const items = [
    { id: 'all', label: `${t('pickSource')} (${rows.reduce((a, r) => a + r.skillCount, 0)})` },
    ...rows.map(x => ({ id: x.key, label: `${x.label} (${x.skillCount})` })),
  ]
  const current = value === 'all' ? null : rows.find(r => r.key === value)
  const label = value === 'all'
    ? `${t('pickSource')} (${rows.reduce((a, r) => a + r.skillCount, 0)})`
    : `${current ? current.label : value} (${current ? current.skillCount : 0})`
  return h('span', { style: { position: 'relative', display: 'inline-flex' } },
    h(P.Button, { variant: 'outline', size: 'sm',
        onClick: () => setOpen(o => !o), title: label },
      label,
      P.IconChevronDownOutline14 ? h(P.IconChevronDownOutline14, { size: 12 }) : ' ▾'),
    open && h('div', { className: 'sk-menu' },
      items.map(item => h('div', {
        key: item.id,
        className: 'sk-menu-item' + (item.id === value ? ' on' : ''),
        role: 'button', tabIndex: 0,
        onClick: () => { onChange(item.id); setOpen(false) },
        onKeyDown: e => { if (e.key === 'Enter' || e.key === ' ') { onChange(item.id); setOpen(false) } },
      }, item.label))))
}

// ── Skill / executor cards ───────────────────────────────────────────────

function SkillCard({ row, s, t, onOpen, onInstall, onDelete, onShare, onToggleVisible, linkedByLabels, onOpenLinker }) {
  const name = shortName(s.name)
  const usage = usageText(s, t)
  const installed = isInstalledRow(s)
  // 反向链接（池技能专用）：数字在前，后随一排链接来源头像。整行可点
  // （stopPropagation 拦住卡片整卡的详情跳转）——弹出放大的链接来源列表，
  // 可多选批量删除链接；悬停列出名称。linkedBy 条目为 { key, name }；
  // 容忍旧宿主/缓存 bundle 错配时的字符串条目（按 key 归一）。
  const linkedBy = Array.isArray(s.linkedBy) && s.linkedBy.length > 0 ? s.linkedBy : null
  const linkedByKeys = linkedBy ? linkedBy.map(e => (e && typeof e === 'object' ? e.key : e)) : null
  const linkedByNames = linkedByKeys ? linkedByKeys.map(k => (linkedByLabels && linkedByLabels[k]) || k || '?') : null
  return h('div', { className: 'sk-card' + (s.isLink ? ' link' : ''), role: 'button', tabIndex: 0,
      onClick: () => onOpen(s),
      onKeyDown: e => e.key === 'Enter' && onOpen(s) },
    h('div', { style: { display: 'flex', gap: 12, alignItems: 'center' } },
      h(Avatar, { name }),
      h('div', { style: { minWidth: 0 } },
        h('div', { className: 'sk-title' }, name),
        (s.fileCount || s.totalSize) && h('div', { className: 'sk-dir' }, `${s.fileCount || 0} · ${formatSize(s.totalSize || 0)} · ${formatTime(s.modifiedAt)}`))),
    h('div', { className: 'sk-desc' }, s.description || ''),
    usage && h('div', { className: 'sk-stats', title: t('usageHint') }, usage),
    linkedBy && h('div', { style: { display: 'flex', alignItems: 'center', margin: '2px 0 6px', cursor: onOpenLinker ? 'pointer' : undefined },
        role: onOpenLinker ? 'button' : undefined, tabIndex: onOpenLinker ? 0 : undefined,
        title: t('linkedByTitle', { names: linkedByNames.join(', ') }),
        onClick: (e) => { if (!onOpenLinker) return; e.stopPropagation(); onOpenLinker(s) },
        onKeyDown: (e) => { if (!onOpenLinker || (e.key !== 'Enter' && e.key !== ' ')) return; e.stopPropagation(); e.preventDefault(); onOpenLinker(s) } },
      h('span', { className: 'sk-hint', style: { fontSize: 12, marginRight: 6 } }, t('linkedByCount', { n: linkedBy.length })),
      linkedByKeys.map((k, i) => h('span', { key: k, title: linkedByNames[i],
        style: { marginLeft: i === 0 ? 0 : -5, lineHeight: 0, position: 'relative', zIndex: i } },
        h(Avatar, { name: linkedByNames[i], size: 18 })))),
    h('div', { className: 'sk-foot' },
      h('div', { className: 'sk-chips' },
        h(Tag, null, row.label),
        // 软链接技能是「虚」的：虚线边框之外再标来源——命中已知执行器根显示其
        // 名称（Agents），否则显示折叠后的目标路径；完整路径放悬停提示。
        s.isLink && h(Tag, { tone: 'accent', title: s.linkTarget || '' },
          `↪ ${t('linkTag')} → ${s.linkExecutor || s.linkTarget || ''}`),
        row.readOnly && h(Tag, { tone: 'danger' }, t('readOnlyTag')),
        s.version && h(Tag, { tone: 'accent' }, 'v' + s.version),
        installed && h(Tag, { tone: 'ok' }, t('installedTag')),
        (row.key === 'dsh' || row.key === 'agents') && s.modelInvocable === false && h(Tag, { tone: 'danger' }, t('hiddenTag'))),
      h('div', { className: 'sk-rowbtns' },
        // Already in the DSH library: offer a disabled state chip instead of an
        // Install button. Re-installing would otherwise hit the server's
        // `skill '<x>' already installed` guard and surface as an error alert.
        row.key !== 'dsh' && (installed
          ? h(ButtonLite, { small: true, disabled: true, title: t('installedTag') }, t('installedTag'))
          : h(ButtonLite, { primary: true, small: true,
            onClick: e => { e.stopPropagation(); onInstall(row, s.installName || s.name) } }, t('toDsh'))),
        (row.key === 'dsh' || row.key === 'agents') && h(ButtonLite, { small: true,
          title: s.modelInvocable === false ? t('restoreAction') : t('hideAction'),
          onClick: e => { e.stopPropagation(); onToggleVisible(row, s.name, s.modelInvocable === false) } },
          s.modelInvocable === false ? t('restoreAction') : t('hideAction')),
        (row.deletable !== false && !row.readOnly) && h(ButtonLite, { danger: true, small: true,
          onClick: e => { e.stopPropagation(); onDelete(row, s.name) } }, t('deleteBtn')),
        onShare && h(ButtonLite, { small: true, title: t('shareBtn'),
          onClick: e => { e.stopPropagation(); onShare(row, s) } }, t('shareBtn')))))
}

/** Tiny variant buttons before P.Button availability resolution settles —
 *  unified through primitives in the browser via data-p-* swap below. */
function ButtonLite({ primary, danger, small, children, ...rest }) {
  const cls = 'sk-btn' + (primary ? ' sk-btn-primary' : '') + (small ? ' sk-btn-sm' : '')
  if (prim('Button')) {
    return h(P.Button, {
      variant: primary ? 'primary' : 'outline',
      size: small ? 'sm' : 'md',
      className: cls,
      ...rest,
    }, children)
  }
  return h('button', {
    className: cls,
    ...rest,
  }, children)
}

function ExecutorCard({ row, t, onEnter }) {
  const count = Array.isArray(row.skills) ? row.skills.length : (row.skillCount || 0)
  const sizeTotal = Array.isArray(row.skills) ? row.skills.reduce((a, s) => a + (s.totalSize || 0), 0) : null
  return h('div', { className: 'sk-card', role: 'button', tabIndex: 0, style: !row.dirExists ? { opacity: 0.5, cursor: 'default' } : undefined,
      onClick: () => row.dirExists && onEnter(row.key),
      onKeyDown: e => e.key === 'Enter' && row.dirExists && onEnter(row.key) },
    h('div', { className: 'sk-head' },
      h(Avatar, { name: row.label, square: true, size: 40 }),
      h('span', { className: 'sk-title' }, row.label),
      row.readOnly && h(Tag, { tone: 'danger' }, t('readOnlyTag')),
      row.key === 'dsh' && h(Tag, { tone: 'accent' }, t('meTag'))),
    h('div', { className: 'sk-countline' },
      row.dirExists
        ? [h('span', { key: 'n', className: 'sk-count' + (count ? '' : ' none') }, String(count)),
           ' ' + t('skillsSuffix') + (sizeTotal != null ? ' · ' + t('totalSize', { size: formatSize(sizeTotal) }) : '')]
        : t('dirNotPresent')),
    h('div', { className: 'sk-dir' }, row.dir))
}

// ── Detail modal ─────────────────────────────────────────────────────────

function DetailModal({ sel, executors, t, onClose, onInstallTo, onDeleted, onMigrated }) {
  const [data, setData] = useState(null)
  const [file, setFile] = useState(null)
  const [fileText, setFileText] = useState('')
  const [confirming, setConfirming] = useState(false)
  const [migrating, setMigrating] = useState(false)
  const [toast, setToast] = useState(false)
  const meta = data?.meta || {}
  const row = sel.executorKey ? executors.find(x => x.key === sel.executorKey) : null
  const installed = isInstalledRow(data)

  useEffect(() => {
    let alive = true
    setData(null)
    const q = `?name=${encodeURIComponent(sel.name)}${sel.executorKey ? '&executor=' + encodeURIComponent(sel.executorKey) : ''}`
    getJson(API + '/detail' + q).then(d => { if (alive) setData(d) }).catch(() => {})
    return () => { alive = false }
  }, [sel])

  const openFile = (f) => {
    setFile(f)
    const q = `?name=${encodeURIComponent(sel.name)}&path=${encodeURIComponent(f.path)}${sel.executorKey ? '&executor=' + encodeURIComponent(sel.executorKey) : ''}`
    fetch(API + '/file' + q).then(r => { if (!r.ok) throw 0; return r.text() }).then(setFileText).catch(() => setFileText(''))
  }

  const doDelete = async () => {
    try {
      const body = { name: sel.name }
      if (sel.executorKey) body.executor = sel.executorKey
      const r = await fetch(API, { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || 'HTTP ' + r.status)
      setConfirming(false)
      onDeleted(sel.name, sel.executorKey || 'dsh')
    } catch (e) { setConfirming(false); alert(t('operationFailed') + ': ' + e.message) }
  }

  const doMigrate = async () => {
    try {
      const body = { name: sel.name }
      if (sel.executorKey) body.executor = sel.executorKey
      const r = await fetch(API + '/migrate-to-pool', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || 'HTTP ' + r.status)
      setMigrating(false)
      const migrated = (await r.json().catch(() => ({}))).migrated
      // 迁移后该技能在原来源变成链接行：重拉详情显示链接字段
      const q = `?name=${encodeURIComponent(sel.name)}${sel.executorKey ? '&executor=' + encodeURIComponent(sel.executorKey) : ''}`
      getJson(API + '/detail' + q).then(d => { setData(d) }).catch(() => {})
      onMigrated && onMigrated(sel.name, migrated)
    } catch (e) { setMigrating(false); alert(t('operationFailed') + ': ' + e.message) }
  }

  const copyContent = () => {
    navigator.clipboard.writeText(data?.content || '').then(() => {
      setToast(true)
      setTimeout(() => setToast(false), 2200)
    }).catch(() => {})
  }

  // 治理键开关（dsh 原生 disable-model-invocation）：对用户库（dsh 行）和
  // user-agents 根（agents 行——dsh 内置扫描 ~/.agents/skills）的技能开放
  const [invBusy, setInvBusy] = useState(false)
  const modelVisible = meta['disable-model-invocation'] !== true
  const toggleInvocation = async () => {
    setInvBusy(true)
    try {
      const r = await fetch(API + '/invocation', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: sel.name, modelInvocable: !modelVisible }) })
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || 'HTTP ' + r.status)
      const q = `?name=${encodeURIComponent(sel.name)}${sel.executorKey ? '&executor=' + encodeURIComponent(sel.executorKey) : ''}`
      getJson(API + '/detail' + q).then(d => { setData(d) }).catch(() => {})
    } catch (e) { alert(t('operationFailed') + ': ' + e.message) } finally { setInvBusy(false) }
  }

  const files = data?.files || []
  const isMd = file ? file.path.endsWith('.md') : true
  const mdLabels = useMemo(() => markdownLabels(t),
    [t('copy'), t('copied'), t('mdCodeLabel'), t('mdCodeWrap'), t('mdCodeUnwrap'), t('mdFootnotes')])

  return h('div', null,
    h(SkDialog, { title: shortName(sel.name), onClose, wide: true },
          h('div', { className: 'sk-page' },
            h('div', { className: 'sk-hint' }, meta.description || meta.whenToUse || ''),
            h('div', { className: 'sk-toolbar' },
              row && row.key !== 'dsh' && !installed && h(P.Button, { variant: 'primary', size: 'sm', onClick: () => onInstallTo && onInstallTo(sel.name, sel.executorKey) }, `${t('installFrom', { label: row.label })}`),
              row && row.key !== 'dsh' && installed && h(Tag, { tone: 'ok' }, t('installedTag')),
              row && row.key === 'dsh' && h(Tag, { tone: 'ok' }, t('activeInDsh')),
              row && (row.key === 'dsh' || row.key === 'agents') && h('span', { className: 'sk-inv-toggle', title: t('invocationHint') },
                h('span', { className: 'sk-dir' }, t('invocationToggle')),
                modelVisible ? h(Tag, { tone: 'ok' }, t('modelVisibleTag')) : h(Tag, { tone: 'danger' }, t('hiddenTag')),
                h(P.Button, { size: 'sm', variant: 'outline', disabled: invBusy, onClick: toggleInvocation },
                  modelVisible ? t('detailHideAction') : t('restoreAction'))),
              row && row.readOnly && h(Tag, { tone: 'danger' }, t('readOnlyTag')),
              h(P.Button, { variant: 'outline', size: 'sm', onClick: copyContent }, t('copy')),
              h('span', { className: 'spacer' }),
              // 迁至共享池：可写来源（或无范围时=dsh 已安装库）的实体技能可用；
              // 已是链接/已在池里的不再提供
              (sel.executorKey ? (row && !row.readOnly) : data?.isInstalled) && data && !data.isLink && !data.inPool &&
                h(P.Button, { variant: 'outline', size: 'sm', onClick: () => setMigrating(true) }, t('migrateBtn')),
              row && !row.readOnly && h(P.Button, { variant: 'outline', size: 'sm', onClick: () => setConfirming(true) }, t('deleteBtn'))),
            h('div', { className: 'sk-meta' },
              h('div', null, h('div', { className: 'sk-dir' }, t('pathLabel')), h('div', { className: 'sk-hint' }, data?.dir || '-')),
              data?.isLink && h('div', null, h('div', { className: 'sk-dir' }, t('linkTargetLabel')), h('div', { className: 'sk-hint', style: { wordBreak: 'break-all' } }, (data.linkExecutor ? data.linkExecutor + ' · ' : '') + (data.linkTarget || ''))),
              h('div', null, h('div', { className: 'sk-dir' }, t('filesCount', { n: data?.fileCount ?? 0 })), h('div', { className: 'sk-hint' }, formatSize(data?.totalSize || 0))),
              data && usageText(data, t) && h('div', null, h('div', { className: 'sk-dir' }, t('usageMetaLabel')), h('div', { className: 'sk-hint', title: t('usageHint') }, usageText(data, t))),
              meta.version && h('div', null, h('div', { className: 'sk-dir' }, 'Version'), h('div', { className: 'sk-hint' }, 'v' + meta.version)),
              meta.author && h('div', null, h('div', { className: 'sk-dir' }, 'Author'), h('div', { className: 'sk-hint' }, meta.author))),
            files.length
              ? h('div', { className: 'sk-filewrap' },
                  h('div', { className: 'sk-files' }, files.map(f =>
                    h('button', { key: f.path, className: 'sk-file' + ((file ? f.path === file.path : f.path === 'SKILL.md') ? ' on' : ''), onClick: () => openFile(f) },
                      h('span', { style: { flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, f.path),
                      h('span', { className: 'sk-dir' }, formatSize(f.size))))),
                  h('div', { className: 'sk-preview sk-md' },
                    isMd && prim('MarkdownText')
                      ? h(P.MarkdownText, { text: file ? fileText : (data?.content || ''), labels: mdLabels })
                      : h('pre', { style: { whiteSpace: 'pre-wrap', margin: 0, fontFamily: 'var(--dsw-font-family)' } }, file ? fileText : (data?.content || ''))))
              : h('div', { className: 'sk-preview sk-md' },
                  prim('MarkdownText')
                    ? h(P.MarkdownText, { text: data?.content || '', labels: mdLabels })
                    : h('pre', { style: { whiteSpace: 'pre-wrap', margin: 0 } }, data?.content || '')))),
    confirming && h(SkDialog, {
      title: t('deleteTitle'),
      onClose: () => setConfirming(false),
      footer: [
        h(ButtonLite, { onClick: () => setConfirming(false) }, t('cancel')),
        h(ButtonLite, { danger: true, primary: true, onClick: doDelete }, t('deleteBtn')),
      ],
    }, h('div', { className: 'sk-hint' }, t('deleteConfirm', { name: sel.name, where: row ? row.label : t('whereDsh') }))),
    migrating && h(SkDialog, {
      title: t('migrateTitle'),
      onClose: () => setMigrating(false),
      footer: [
        h(ButtonLite, { onClick: () => setMigrating(false) }, t('cancel')),
        h(ButtonLite, { primary: true, onClick: doMigrate }, t('migrateBtn')),
      ],
    }, h('div', { className: 'sk-hint' }, t('migrateConfirm', { name: sel.name, pool: data?.poolDir || '~/.agents/skills' }))),
    toast && h(InToast, { text: t('copied') }))
}

/** In-page dialog: rendered INSIDE the fullscreen overlay's stacking context
 *  so it can never fall behind it (host Modal portals to <body> with a lower
 *  z-index than the fullscreen page and would be invisible). */
function SkDialog({ title, onClose, footer, children, wide }) {
  return h('div', { className: 'sk-dlg-backdrop', onClick: onClose },
    h('div', { className: 'sk-dlg', style: wide ? { maxWidth: 920, width: '92vw' } : undefined,
        onClick: e => e.stopPropagation() },
      title && h('h3', null, title),
      children,
      footer && h('div', { className: 'sk-dlg-foot' }, footer)))
}

function InToast({ text }) {
  return h('div', { className: 'sk-toast' }, text)
}

let _actionShareDialog = null
function getActionShareDialog() {
  if (_actionShareDialog === null) _actionShareDialog = PluginKit.makeActionShareDialog(__React)
  return _actionShareDialog
}

/** 分享抽屉：壳交给 PluginKit（ActionShareDialog），本插件只负责
 *  hasToken 提示、settingsFile 插值与 run/poll 的 API 映射。 */
function ShareSkillDialog({ t, params, onClose }) {
  const _st = useState(null)
  const status = _st[0]; const setStatus = _st[1]
  useEffect(() => {
    getJson(API + '/market/status').then((d) => setStatus(d)).catch(() => setStatus({ hasToken: false }))
  }, [])
  const hasToken = status ? status.hasToken === true : null
  const hint = hasToken === false ? t('shareHintPatMissing') : t('shareHint')
  const initialPrompt = PluginKit.substituteParams(SHARE_PROMPT_ZH, { ...params, settingsFile: (status && status.settingsFile) || '' })
  return h(getActionShareDialog(), {
    title: t('shareTitle'), hint, initialPrompt,
    rows: [[t('shareParamName'), params.skillName], [t('shareParamVersion'), params.version || '-'], [t('shareParamDir'), params.resourceDir]],
    labels: { copy: t('copyPrompt'), copied: t('copied'), run: t('runBtn'), running: t('running'), done: t('runDone'), failed: t('runFailed'), outputLabel: t('outputLabel') },
    run: (prompt) => fetch(API + '/share/run', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prompt, dir: params.resourceDir }) }).then((r) => r.json()),
    poll: (id) => fetch(API + '/share/run?id=' + encodeURIComponent(id)).then((r) => r.json()),
    onClose,
  })
}

/** Market sync settings: status card, sync action, editable url/branch. */
function MarketSettingsDialog({ t, onClose, onToast, onSynced }) {
  const [status, setStatus] = useState(null)
  const [busy, setBusy] = useState(false)
  const [url, setUrl] = useState('')
  const [branch, setBranch] = useState('')
  const [token, setToken] = useState('')
  const [repoDir, setRepoDir] = useState('')
  const [autoSync, setAutoSync] = useState(true)
  const [syncOnStartup, setSyncOnStartup] = useState(true)
  const [publishMarket, setPublishMarket] = useState(false)

  const refresh = () => getJson(API + '/market/status').then(d => {
    setStatus(d)
    setUrl(d.url)
    setBranch(d.branch)
    setRepoDir(d.dir)
    setAutoSync(d.autoSync)
    setSyncOnStartup(d.syncOnStartup)
    setPublishMarket(!!d.publishMarket)
  }).catch(() => {})
  useEffect(() => { refresh() }, [])

  const doSync = async () => {
    setBusy(true)
    try {
      const r = await fetch(API + '/market/sync', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })
      const d = await r.json().catch(() => ({}))
      if (!r.ok) throw new Error(d.error || 'HTTP ' + r.status)
      onToast(d.isFirstClone ? t('firstCloneDone') : d.hasUpdates ? t('syncDoneUpdated') : t('syncDoneLatest'))
      onSynced && onSynced()
      refresh()
    } catch (e) { onToast(t('operationFailed') + ': ' + e.message) } finally { setBusy(false) }
  }
  const putSettings = async (patch) => {
    const r = await fetch(API + '/market/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(patch) })
    if (!r.ok) throw new Error('HTTP ' + r.status)
    return r.json().catch(() => ({}))
  }
  const doSave = async () => {
    try {
      const patch = { url, branch, autoSync, syncOnStartup, publishMarket }
      if (repoDir !== '' && repoDir !== (status && status.dir)) patch.repoDir = repoDir
      if (token !== '') patch.token = token
      await putSettings(patch)
      setToken('')
      onToast(t('saved'))
      refresh()
    } catch (e) { onToast(t('operationFailed') + ': ' + e.message) }
  }
  const doClearToken = async () => {
    try {
      await putSettings({ token: null })
      onToast(t('saved'))
      refresh()
    } catch (e) { onToast(t('operationFailed') + ': ' + e.message) }
  }

  const short = (c) => (c ? String(c).slice(0, 8) : '-')
  const row = (label, value) => h('div', { style: { display: 'flex', justifyContent: 'space-between', gap: 12, padding: '3px 0' } },
    h('span', { className: 'sk-dir' }, label), h('span', { className: 'sk-hint', style: { wordBreak: 'break-all', textAlign: 'right' } }, value))

  return h(SkDialog, { title: t('marketSettings'), onClose },
    h('div', { style: { minWidth: 380, display: 'flex', flexDirection: 'column', gap: 10 } },
      status === null
        ? h(Spinner, { label: '…' })
        : [
          status.gitAvailable === false && h('div', { className: 'sk-tag danger' }, t('gitMissing')),
          h('div', null,
            row(t('repoUrlLabel'), status.url),
            row(t('branchLabel'), status.branch),
            row(t('localCommitLabel'), short(status.localCommit) + (status.needsUpdate ? ' · ' : '')),
            status.needsUpdate !== undefined && h('div', { style: { display: 'flex', justifyContent: 'flex-end', marginTop: -6 } },
              status.needsUpdate ? h('span', { className: 'sk-tag accent' }, t('needsUpdateTag')) : null),
            row(t('remoteCommitLabel'), short(status.remoteCommit)),
            row(t('lastSyncLabel'), status.lastSyncAt ? formatTime(status.lastSyncAt) : t('repoMissing')),
            row(t('repoDirLabel'), status.dir)),
          h('div', { style: { display: 'flex', flexDirection: 'column', gap: 6 } },
            h('label', { style: { display: 'flex', alignItems: 'center', gap: 8, color: 'var(--dsw-alias-label-secondary)', fontSize: 13 } },
              h('input', { type: 'checkbox', checked: autoSync, onChange: e => setAutoSync(e.target.checked) }), t('autoSyncLabel')),
            h('label', { style: { display: 'flex', alignItems: 'center', gap: 8, color: 'var(--dsw-alias-label-secondary)', fontSize: 13 } },
              h('input', { type: 'checkbox', checked: syncOnStartup, onChange: e => setSyncOnStartup(e.target.checked) }), t('syncOnStartupLabel')),
            h('label', { style: { display: 'flex', alignItems: 'center', gap: 8, color: 'var(--dsw-alias-label-secondary)', fontSize: 13 } },
              h('input', { type: 'checkbox', checked: publishMarket, onChange: e => setPublishMarket(e.target.checked) }), t('publishMarketLabel')),
            h('div', { className: 'sk-hint', style: { fontSize: 12 } }, t('publishMarketHint'))),
          h('div', { style: { display: 'flex', flexDirection: 'column', gap: 6 } },
            h('input', { className: 'sk-input', value: url, onChange: e => setUrl(e.target.value), placeholder: t('repoUrlLabel'), style: { width: '100%' } }),
            h('input', { className: 'sk-input', value: branch, onChange: e => setBranch(e.target.value), placeholder: t('branchLabel'), style: { width: '100%' } }),
            h('input', { className: 'sk-input', value: repoDir, onChange: e => setRepoDir(e.target.value), placeholder: t('repoDirLabel'), style: { width: '100%' } }),
            h('div', { style: { display: 'flex', gap: 6, alignItems: 'center' } },
              h('input', { className: 'sk-input', type: 'password', value: token, onChange: e => setToken(e.target.value),
                placeholder: status && status.hasToken ? `${t('tokenLabel')} · ${t('tokenConfigured')}` : t('tokenLabel'), style: { flex: 1 } }),
              status && status.hasToken && h(ButtonLite, { onClick: doClearToken }, t('clearToken')))),
          h('div', { className: 'sk-dlg-foot', style: { marginTop: 4 } },
            h(ButtonLite, { onClick: doSave }, t('save')),
            h(ButtonLite, { primary: true, onClick: doSync }, busy ? t('syncing') : t('syncNow')))]))
}

/** 执行器目录管理：内置行与自动发现行（~/.xxx/skills 约定）可改目录/停用
 * （dsh 锁定；cordis 配置管理的行只展示），自定义行可增删改。保存 = 整表 PUT
 *  executor-settings（replace 语义），服务端逐行校验（key kebab、重复、dsh
 *  锁定），改完即时生效无需重启。 */
function ExecutorSettingsDialog({ t, onClose, onToast, onChanged }) {
  const [rows, setRows] = useState(null)
  const [busy, setBusy] = useState(false)
  const [restoreArmed, setRestoreArmed] = useState(false)
  // 行的 React key 必须稳定：不能用 r.key——它是可编辑字段，逐字输入会整行
  // 重挂载、输入框丢焦点（每个字符后）。__id 在行创建/载入时分配。
  const rowSeq = useRef(0)
  const withIds = (list) => (Array.isArray(list) ? list : []).map((r) => ({ ...r, __id: 'r' + (++rowSeq.current) }))

  const applySheet = (d) => setRows(withIds(d && d.executors))
  const refresh = () => getJson(API + '/executor-settings')
    .then(applySheet)
    .catch(e => onToast(t('operationFailed') + ': ' + e.message))
  useEffect(() => { refresh() }, [])

  const KEBAB = /^[a-z0-9]+(?:-[a-z0-9]+)*$/
  const patchRow = (index, patch) => setRows(rs => rs.map((r, i) => i === index ? { ...r, ...patch } : r))
  const removeRow = (index) => setRows(rs => rs.filter((_, i) => i !== index))
  const addRow = () => setRows(rs => [...rs, { __id: 'r' + (++rowSeq.current), key: '', label: '', dir: '', source: 'custom', locked: false, managedByConfig: false, disabled: false, overridden: false, defaultDir: '' }])

  const validate = () => {
    const customs = rows.filter(r => r.source === 'custom' && !r.managedByConfig)
    for (const r of customs) {
      if (!KEBAB.test(String(r.key || '').trim())) return t('execKeyInvalid')
      if (!String(r.dir || '').trim()) return t('execDirRequired')
    }
    const keys = customs.map(r => String(r.key || '').trim())
    if (keys.some((k, i) => keys.indexOf(k) !== i)) return t('execKeyDup')
    return undefined
  }

  const saveSheet = async (sheet) => {
    const r = await fetch(API + '/executor-settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(sheet) })
    const d = await r.json().catch(() => ({}))
    if (!r.ok) throw new Error(d.error || 'HTTP ' + r.status)
    applySheet(d)
    setRestoreArmed(false)
    onToast(t('saved'))
    onChanged && onChanged()
  }
  const doSave = async () => {
    if (!rows) return
    const err = validate()
    if (err) { onToast(t('operationFailed') + ': ' + err); return }
    setBusy(true)
    try {
      const dirs = {}
      const disabled = []
      for (const r of rows) {
        if (r.locked || r.managedByConfig) continue
        if (r.source !== 'builtin' && r.source !== 'auto') continue
        if (r.disabled) disabled.push(r.key)
        const dir = String(r.dir || '').trim()
        // 等于默认值的覆盖不落盘（保持 sheet 干净）；已在 sheet 里的条目原样带回
        if (dir !== '' && (r.overridden || dir !== r.defaultDir)) dirs[r.key] = dir
      }
      const extra = rows
        .filter(r => r.source === 'custom' && !r.managedByConfig)
        .map(r => ({ key: String(r.key || '').trim(), label: String(r.label || '').trim() || String(r.key || '').trim(), dir: String(r.dir || '').trim() }))
      await saveSheet({ dirs, disabled, extra })
    } catch (e) { onToast(t('operationFailed') + ': ' + e.message) } finally { setBusy(false) }
  }
  const doRestore = async () => {
    if (!restoreArmed) { setRestoreArmed(true); return }
    setBusy(true)
    try { await saveSheet({ dirs: {}, disabled: [], extra: [] }) }
    catch (e) { onToast(t('operationFailed') + ': ' + e.message) } finally { setBusy(false) }
  }

  const tag = (text, tone) => h('span', { className: 'sk-tag' + (tone ? ' ' + tone : '') }, text)
  const rowEl = (r, i) => {
    const editable = !r.locked && !r.managedByConfig
    return h('div', { key: r.__id, style: { display: 'flex', flexDirection: 'column', gap: 6,
        padding: '8px 10px', border: '1px solid var(--dsw-alias-border-l1)', borderRadius: 10, opacity: r.disabled ? 0.55 : 1 } },
      h('div', { style: { display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' } },
        h('span', { className: 'sk-tag' }, r.source === 'builtin' ? t('execSourceBuiltin') : r.source === 'auto' ? t('execSourceAuto') : t('execSourceCustom')),
        r.source === 'custom' && editable
          ? h('input', { className: 'sk-input', value: r.key, placeholder: t('execKeyPlaceholder'), style: { width: 160 }, onChange: e => patchRow(i, { key: e.target.value }) })
          : h('span', { className: 'sk-title' }, r.label),
        r.source === 'custom' && editable
          ? h('input', { className: 'sk-input', value: r.label, placeholder: t('execNamePlaceholder'), style: { width: 140 }, onChange: e => patchRow(i, { label: e.target.value }) })
          : null,
        r.locked && tag(t('execLockedTag')),
        !r.locked && r.managedByConfig && tag(t('execManagedTag')),
        r.disabled && tag(t('execDisabledTag'), 'danger'),
        h('span', { style: { flex: 1 } }),
        (r.source === 'builtin' || r.source === 'auto') && editable
          ? h('label', { style: { display: 'flex', alignItems: 'center', gap: 4, fontSize: 12.5, color: 'var(--dsw-alias-label-secondary)', whiteSpace: 'nowrap', cursor: 'pointer' } },
              h('input', { type: 'checkbox', checked: !r.disabled, onChange: e => patchRow(i, { disabled: !e.target.checked }) }), t('execEnabledLabel'))
          : null,
        r.source === 'custom' && editable
          ? h(ButtonLite, { small: true, onClick: () => removeRow(i) }, t('execRemove'))
          : null),
      editable
        ? h('input', { className: 'sk-input', value: r.dir, placeholder: t('execDirPlaceholder'), style: { width: '100%' }, onChange: e => patchRow(i, { dir: e.target.value }) })
        : h('div', { className: 'sk-dir' }, r.dir))
  }

  return h(SkDialog, { title: t('executorSettings'), onClose, wide: true },
    rows === null
      ? h(Spinner, { label: '…' })
      : h('div', { style: { display: 'flex', flexDirection: 'column', gap: 8 } }, [
          h('div', { className: 'sk-hint' }, t('executorSettingsHint')),
          ...rows.map(rowEl),
          h('div', { style: { textAlign: 'center' } },
            h(ButtonLite, { small: true, onClick: addRow }, '+ ' + t('execAdd'))),
          restoreArmed && h('div', { className: 'sk-tag danger', style: { alignSelf: 'flex-end' } }, t('execRestoreConfirm')),
          h('div', { className: 'sk-dlg-foot', style: { marginTop: 2 } },
            h(ButtonLite, { onClick: doRestore }, t('execRestore')),
            h('span', { style: { flex: 1 } }),
            h(ButtonLite, { primary: true, disabled: busy, onClick: doSave }, t('save'))),
        ]))
}

/** 回收站：删除的技能暂存列表（服务端读取时已惰性清理过期项）。恢复按元数据
 *  originalDir 放回原处，原位置被占用则服务端拒绝；彻底删除/清空不可恢复。 */
function TrashView({ t, onToast, onChanged }) {
  const [data, setData] = useState(null)
  const [busy, setBusy] = useState(false)
  const [confirm, setConfirm] = useState(null) // { kind: 'restore' | 'forever', entry }
  const [emptyArmed, setEmptyArmed] = useState(false)

  const refresh = () => getJson(API + '/trash')
    .then(d => { setData(d); setEmptyArmed(false) })
    .catch(e => onToast(t('operationFailed') + ': ' + e.message))
  useEffect(() => { refresh() }, [])

  const mutate = async (url, method, body) => {
    const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || 'HTTP ' + r.status)
  }
  const act = async (fn, toast, changedKey) => {
    setBusy(true)
    try {
      await fn()
      setConfirm(null)
      onToast(toast)
      refresh()
      onChanged && onChanged(changedKey) // 恢复后来源列表重新出现该技能
    } catch (e) { onToast(t('operationFailed') + ': ' + e.message) } finally { setBusy(false) }
  }
  const doRestore = (entry) => act(() => mutate(API + '/trash/restore', 'POST', { id: entry.id }), t('restoredToast'), entry.executorKey)
  const doForever = (entry) => act(() => mutate(API + '/trash', 'DELETE', { id: entry.id }), t('deletedForeverToast'))
  const doEmpty = () => act(() => mutate(API + '/trash', 'DELETE', { all: true }), t('emptiedTrashToast'))

  if (data === null) return h(Spinner, { label: '…' })
  const entries = data.entries || []
  const rowEl = (entry) =>
    h('div', { key: entry.id, style: { display: 'flex', flexDirection: 'column', gap: 4,
        padding: '8px 10px', border: '1px solid var(--dsw-alias-border-l1)', borderRadius: 10 } },
      h('div', { style: { display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' } },
        h('span', { className: 'sk-title' }, entry.name),
        entry.executorKey && h('span', { className: 'sk-tag' }, entry.executorKey),
        !entry.restorable && h('span', { className: 'sk-tag danger' }, t('trashNoRestoreTag')),
        h('span', { style: { flex: 1 } }),
        h('span', { className: 'sk-hint', style: { fontSize: 12 } },
          `${formatSize(entry.totalSize || 0)} · ${t('trashDeletedAtLabel')} ${entry.deletedAt ? formatTime(entry.deletedAt) : '-'}`),
        h(ButtonLite, { small: true, disabled: busy || !entry.restorable, onClick: () => setConfirm({ kind: 'restore', entry }) }, t('restoreBtn')),
        h(ButtonLite, { small: true, danger: true, disabled: busy, onClick: () => setConfirm({ kind: 'forever', entry }) }, t('deleteForeverBtn'))),
      entry.description && h('div', { className: 'sk-hint' }, entry.description),
      entry.originalDir && h('div', { className: 'sk-dir' }, entry.originalDir))

  return [
    h('div', { className: 'sk-toolbar', key: 'bar' },
      h('span', { className: 'sk-hint' }, t('trashHint')),
      data.enabled === true && h('span', { className: 'sk-tag' },
        data.retentionDays === null ? t('trashKeepForever') : t('trashRetentionDays', { n: data.retentionDays })),
      h('span', { className: 'spacer' }),
      data.enabled === true && entries.length > 0 && h(ButtonLite, { small: true, disabled: busy,
        onClick: () => (emptyArmed ? doEmpty() : setEmptyArmed(true)) }, t('emptyTrashBtn'))),
    emptyArmed && entries.length > 0 && h('div', { key: 'arm', className: 'sk-tag danger', style: { alignSelf: 'flex-end' } },
      t('emptyTrashConfirm', { n: entries.length })),
    h('div', { key: 'list', style: { display: 'flex', flexDirection: 'column', gap: 8 } },
      data.enabled !== true
        ? h(Empty, null, t('trashDisabled'))
        : entries.length === 0
          ? h(Empty, null, t('trashEmpty'))
          : entries.map(rowEl)),
    confirm && h(SkDialog, {
      title: confirm.kind === 'restore' ? t('restoreBtn') : t('deleteForeverBtn'),
      onClose: () => setConfirm(null),
      footer: [
        h(ButtonLite, { onClick: () => setConfirm(null) }, t('cancel')),
        h(ButtonLite, { primary: true, danger: confirm.kind === 'forever', disabled: busy,
          onClick: () => (confirm.kind === 'restore' ? doRestore(confirm.entry) : doForever(confirm.entry)) },
          confirm.kind === 'restore' ? t('restoreBtn') : t('deleteForeverBtn')),
      ],
    }, h('div', { className: 'sk-hint' },
      confirm.kind === 'restore'
        ? t('restoreConfirm', { name: confirm.entry.name, dir: confirm.entry.originalDir || '-' })
        : t('deleteForeverConfirm', { name: confirm.entry.name }))),
  ]
}

/** 链接来源列表（池技能卡片反向链接行的弹窗）：放大的执行器头像 + 名称，
 *  勾选后批量删除——走普通 DELETE 通道，链接移入回收站，池中技能本体不动。
 *  rows 是本地副本：删除成功的行就地移除，全部删完自动关闭。 */
function LinkedByDialog({ t, skill, executorLabels, onClose, onToast, onChanged, onRefreshCandidates }) {
  // 版本错配兜底：旧宿主给字符串条目时，链接名只能按技能本名猜
  const [rows, setRows] = useState(() => (Array.isArray(skill.linkedBy) ? skill.linkedBy : [])
    .map((e) => (e && typeof e === 'object' ? e : { key: e, name: skill.name })))
  // 打开即拉新 summary：执行器目录可能已在页面加载后变化（如迁移新建的池）
  useEffect(() => { onRefreshCandidates && onRefreshCandidates() }, [])
  const [selected, setSelected] = useState({})
  const [busy, setBusy] = useState(false)
  const toggle = (key) => setSelected(s => ({ ...s, [key]: !s[key] }))
  const selectAll = () => setSelected(Object.fromEntries(rows.map((e) => [e.key, true])))
  const invert = () => setSelected((s) => Object.fromEntries(rows.map((e) => [e.key, !s[e.key]])))
  const count = rows.filter(e => selected[e.key]).length

  const doDelete = async () => {
    const targets = rows.filter(e => selected[e.key])
    if (targets.length === 0) return
    setBusy(true)
    const failed = []
    const done = []
    for (const e of targets) {
      try {
        const r = await fetch(API, { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: e.name, executor: e.key }) })
        if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || 'HTTP ' + r.status)
        done.push(e.key)
      } catch (err) { failed.push(`${(executorLabels && executorLabels[e.key]) || e.key}: ${err.message}`) }
    }
    setBusy(false)
    if (failed.length > 0) onToast(t('operationFailed') + ': ' + failed.join('; '))
    if (done.length > 0) onToast(t('deletedLinksToast', { n: done.length }))
    const rest = rows.filter(e => !done.includes(e.key))
    setSelected({})
    if (done.length > 0) onChanged && onChanged(done) // 池行 linkedBy 已变：让上层定点失效
    if (rest.length === 0) { onClose(); return }
    setRows(rest)
  }

  return h(SkDialog, { title: t('linkedByDialogTitle', { n: rows.length }), onClose },
    h('div', { className: 'sk-hint', style: { marginBottom: 8 } }, t('linkedByDialogHint')),
    h('div', { style: { display: 'flex', flexDirection: 'column', gap: 6 } },
      rows.map((e) => {
        const label = (executorLabels && executorLabels[e.key]) || e.key
        return h('label', { key: e.key, style: { display: 'flex', alignItems: 'center', gap: 10,
            padding: '8px 10px', border: '1px solid var(--dsw-alias-border-l1)', borderRadius: 10, cursor: 'pointer' } },
          h('input', { type: 'checkbox', checked: !!selected[e.key], onChange: () => toggle(e.key), disabled: busy }),
          h('span', { style: { lineHeight: 0 } }, h(Avatar, { name: label, size: 28 })),
          h('span', { className: 'sk-title' }, label),
          e.name !== skill.name && h('span', { className: 'sk-hint', style: { fontSize: 12 } }, `← ${e.name}`))
      })),
    h('div', { className: 'sk-dlg-foot', style: { marginTop: 8 } },
      h(ButtonLite, { small: true, disabled: busy || rows.length === 0, onClick: selectAll }, t('selectAllBtn')),
      h(ButtonLite, { small: true, disabled: busy || rows.length === 0, onClick: invert }, t('invertSelectionBtn')),
      h('span', { style: { flex: 1 } }),
      h(ButtonLite, { onClick: onClose }, t('cancel')),
      h(ButtonLite, { primary: true, danger: count > 0, disabled: count === 0 || busy, onClick: doDelete },
        t('deleteSelectedBtn', { n: count }))))
}

/** 安装对话框（卡片/详情「安装」入口）：默认勾选 DSH 技能库，「更多执行器」
 *  展开后可勾选其它来源（目录存在、可写、非来源自身）。选择记忆在
 *  localStorage，下次打开沿用；上次勾了别的执行器则自动展开。全部成功才
 *  落记忆并关闭；部分失败时失败行标注原因、对话框保留。 */
function InstallToDialog({ t, name, from, executors, onClose, onToast, onChanged, onRefreshCandidates }) {
  useEffect(() => { onRefreshCandidates && onRefreshCandidates() }, [])
  const dshRow = executors.find(r => r.key === 'dsh')
  const others = executors.filter(r => r.key !== 'dsh' && r.key !== from && r.dirExists && !r.readOnly)
  const candidates = dshRow ? [dshRow, ...others] : others
  const [selected, setSelected] = useState(() => {
    const saved = loadInstallTargets().filter(k => candidates.some(c => c.key === k))
    const initial = saved.length > 0 ? saved : (dshRow ? ['dsh'] : [])
    return Object.fromEntries(initial.map(k => [k, true]))
  })
  // 上次选择含非 dsh 目标 → 自动展开更多执行器
  const [expanded, setExpanded] = useState(() => Object.keys(selected).some(k => k !== 'dsh'))
  const [errors, setErrors] = useState({})
  const [busy, setBusy] = useState(false)
  const toggle = (key) => setSelected(s => ({ ...s, [key]: !s[key] }))
  const othersShown = expanded ? candidates.filter(c => c.key !== 'dsh') : []
  const selectAll = () => setSelected(Object.fromEntries(candidates.map((e) => [e.key, true])))
  const invert = () => setSelected((s) => Object.fromEntries(candidates.map((e) => [e.key, !s[e.key]])))
  const count = candidates.filter(e => selected[e.key]).length

  const doInstall = async () => {
    const targets = candidates.filter(e => selected[e.key]).map(e => e.key)
    if (targets.length === 0 || busy) return
    setBusy(true)
    try {
      const body = { name, targets }
      if (from) body.from = from
      const r = await fetch(API + '/install-to', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
      const d = await r.json().catch(() => ({}))
      if (!r.ok) throw new Error(d.error || 'HTTP ' + r.status)
      const okKeys = [], errs = {}
      for (const res of d.results || []) {
        if (res.ok) okKeys.push(res.key)
        else errs[res.key] = res.error || 'failed'
      }
      setErrors(errs)
      if (okKeys.length > 0) {
        onToast(t('installedToToast', { n: okKeys.length }))
        onChanged && onChanged(okKeys)
      }
      if (Object.keys(errs).length === 0) {
        saveInstallTargets(targets) // 记住上次选择（全部成功才落，不带回失败项）
        onClose()
      }
    } catch (e) { onToast(t('operationFailed') + ': ' + e.message) } finally { setBusy(false) }
  }

  const rowEl = (e) =>
    h('label', { key: e.key, style: { display: 'flex', alignItems: 'center', gap: 10,
        padding: '8px 10px', border: '1px solid var(--dsw-alias-border-l1)', borderRadius: 10, cursor: 'pointer' } },
      h('input', { type: 'checkbox', checked: !!selected[e.key], onChange: () => toggle(e.key), disabled: busy }),
      h('span', { style: { lineHeight: 0 } }, h(Avatar, { name: e.label, size: 28 })),
      h('span', { className: 'sk-title' }, e.label),
      h('span', { className: 'sk-hint', style: { fontSize: 12 } }, e.dir),
      errors[e.key] && h('span', { className: 'sk-tag danger' }, errors[e.key]))

  return h(SkDialog, { title: t('installToTitle'), onClose },
    h('div', { className: 'sk-hint', style: { marginBottom: 8 } }, t('installToHint', { name })),
    h('div', { style: { display: 'flex', flexDirection: 'column', gap: 6 } },
      dshRow && rowEl(dshRow),
      othersShown.map(rowEl),
      !expanded && others.length > 0 && h(ButtonLite, { small: true, onClick: () => setExpanded(true) }, t('moreExecutorsBtn'))),
    candidates.length === 0 && h(Empty, null, t('noInstallTargets')),
    h('div', { className: 'sk-dlg-foot', style: { marginTop: 8 } },
      expanded && h(ButtonLite, { small: true, disabled: busy, onClick: selectAll }, t('selectAllBtn')),
      expanded && h(ButtonLite, { small: true, disabled: busy, onClick: invert }, t('invertSelectionBtn')),
      h('span', { style: { flex: 1 } }),
      h(ButtonLite, { onClick: onClose }, t('cancel')),
      h(ButtonLite, { primary: true, disabled: count === 0 || busy, onClick: doInstall }, t('installToBtn', { n: count }))))
}

/** 增量网格：先渲染前 pageSize 张，按需增长——市场集合有 6k+ 条，不能一次全挂。
 *  以「当前筛选」作 key，让筛选变化时重置窗口。
 *  [性能] pageSize 从 120 降到 60：首屏要一次性挂载全部卡片，120 张的
 *  Avatar 渐变 / 时间格式化 / 注入开销文案开销明显，60 张已够撑满首屏。 */
function PagedGrid({ items, render, t, pageSize = 60, grow = 120, keyPrefix = '' }) {
  const [shown, setShown] = useState(pageSize)
  return [
    h('div', { className: 'sk-grid' }, items.slice(0, shown).map(render)),
    items.length > shown && h('div', { style: { textAlign: 'center', margin: '14px 0' } },
      h(ButtonLite, { onClick: () => setShown(n => n + grow) }, t('showMore', { n: items.length - shown }))),
  ]
}

// ── Views ────────────────────────────────────────────────────────────────

function CardsView({ executors, t, onEnter, onBrowseAll, onOpenSettings }) {
  if (!executors.length) return [
    // 空列表也要留设置入口：全部执行器被停用/目录为空时仍能进管理弹窗
    h('div', { className: 'sk-toolbar' },
      h('span', { className: 'sk-hint' }, t('cardsHint')),
      h('span', { className: 'spacer' }),
      h(ButtonLite, { onClick: onOpenSettings }, t('executorSettings'))),
    h(Empty, null, t('noExecutors')),
  ]
  const present = executors.filter(r => r.dirExists)
  const missing = executors.filter(r => !r.dirExists)
  return [
    h('div', { className: 'sk-toolbar' },
      h('span', { className: 'sk-hint' }, t('cardsHint')),
      h('span', { className: 'spacer' }),
      h(P.Button, { variant: 'primary', size: 'sm', onClick: onBrowseAll }, `${t('browseAll')} (${executors.reduce((a, r) => a + r.skillCount, 0)})`),
      h('span', { style: { width: 6 } }),
      h(ButtonLite, { onClick: onOpenSettings, title: t('executorSettings') }, t('executorSettings')),
      h('span', { style: { width: 6 } }),
      h('span', { className: 'sk-refresh-slot' })),
    h('div', { className: 'sk-src' },
      present.map(row => h(ExecutorCard, { key: row.key, row, t, onEnter }))),
    missing.length > 0 && [
      h('div', { className: 'sk-hint', style: { marginTop: 6 } }, t('notFoundGroup', { n: missing.length })),
      h('div', { className: 'sk-src' },
        missing.map(row => h(ExecutorCard, { key: row.key, row, t, onEnter }))),
    ],
  ]
}

function AllSkillsView({ executors, searchText, sourceFilter, sortBy, t, onSearch, onFilter, onSort, onBack, onOpen, onInstall, onDelete, onShare, onToggleVisible }) {
  const pending = executors.some(x => x.dirExists && !Array.isArray(x.skills))
  if (pending) return h(Spinner, { label: t('loadingCatalogs') })
  let items = []
  for (const row of executors) {
    if (!row.dirExists || !Array.isArray(row.skills)) continue
    if (sourceFilter !== 'all' && row.key !== sourceFilter) continue
    for (const s of row.skills) items.push({ row, s })
  }
  if (searchText) items = items.filter(it => matchSkill(it.s, searchText.toLowerCase()))
  items = sortSkills(items, sortBy, it => it.s)
  return [
    h('div', { className: 'sk-head' },
      h(P.Button, { variant: 'ghost', size: 'sm', onClick: onBack }, t('backCards')),
      h('span', { className: 'sk-title' }, t('title')),
      h(InputBox, { value: searchText, placeholder: t('searchAll'), onSearch }),
      // SourceFilter owns a useState, so it must be mounted as an element. Calling it
      // as a plain function attributes that hook to AllSkillsView — which returns the
      // Spinner early (zero hooks) while catalogs load, then renders one hook once they
      // arrive: React throws "Rendered more hooks than during the previous render".
      h(SourceFilter, { rows: executors.filter(r => r.dirExists), value: sourceFilter, onChange: onFilter, t }),
      SortSelect({ value: sortBy, onChange: onSort, t }),
      h('span', { className: 'spacer' }),
      h(Tag, null, `${items.length} ${t('skillsSuffix')}`)),
    !items.length
      ? h(Empty, null, t('emptySearch'))
      : h('div', { className: 'sk-grid' }, items.map(({ row, s }) =>
          h(SkillCard, { key: row.key + '/' + s.name, row, s, t, onOpen, onInstall, onDelete, onShare, onToggleVisible })))]
}

function DrillInView({ row, searchText, sortBy, t, onSearch, onSort, onBack, onOpen, onInstall, onDelete, onShare, onToggleVisible, executorLabels, onOpenLinker }) {
  if (!row) return null
  if (!row.dirExists) {
    return [
      h('div', { className: 'sk-head' },
        h(P.Button, { variant: 'ghost', size: 'sm', onClick: onBack }, t('backAll'))),
      h(Empty, null, `${row.label} — ${row.dir}`)]
  }
  if (!Array.isArray(row.skills)) {
    return h(Spinner, { label: t('scanning', { label: row.label }) })
  }
  let skills = row.skills
  if (searchText) skills = skills.filter(s => matchSkill(s, searchText.toLowerCase()))
  skills = sortSkills(skills, sortBy)
  return [
    h('div', { className: 'sk-head' },
      h(P.Button, { variant: 'ghost', size: 'sm', onClick: onBack }, t('backAll')),
      h('span', { className: 'sk-title' }, row.label),
      h('span', { className: 'sk-tag' }, `${skills.length} ${t('skillsSuffix')}`),
      row.readOnly && h(Tag, { tone: 'danger' }, t('readOnlyTag')),
      h(InputBox, { value: searchText, placeholder: t('filterWithin', { label: row.label }), onSearch }),
      SortSelect({ value: sortBy, onChange: onSort, t }),
      h('span', { className: 'spacer' }),
      h('span', { className: 'sk-dir' }, row.dir)),
    !skills.length
      ? h(Empty, null, searchText ? t('emptySearch') : t('emptySkillsIn', { label: row.label }))
      : h(PagedGrid, { key: 'ed' + row.key + sortBy, items: skills, t,
          render: s => h(SkillCard, { key: s.name, row, s, t, onOpen, onInstall, onDelete, onShare, onToggleVisible, linkedByLabels: executorLabels, onOpenLinker }) }),
  ]
}

function InputBox({ value, placeholder, onSearch }) {
  // [性能] 本地暂存 + 300ms 防抖。原实现每次击键都把值冒泡到 SkillsPage 的 setState，
  // 而网格的 key 含搜索词 → 每敲一个字符就整体重建一次卡片网格。
  // 输入框自身保持即时回显；外部重置（切 tab 等）仍会同步回来。
  const [local, setLocal] = useState(value)
  const sentRef = useRef(value)
  const timerRef = useRef(null)
  useEffect(() => {
    if (value !== sentRef.current) { sentRef.current = value; setLocal(value) }
  }, [value])
  useEffect(() => () => { if (timerRef.current) clearTimeout(timerRef.current) }, [])
  const emit = (next) => {
    setLocal(next)
    if (timerRef.current) clearTimeout(timerRef.current)
    timerRef.current = setTimeout(() => { sentRef.current = next; onSearch(next) }, 300)
  }
  if (prim('Input')) {
    return h(P.Input, { value: local, placeholder, className: 'sk-input', onChange: e => emit(e.target.value),
      style: { minWidth: 220 } })
  }
  return h('input', { value: local, placeholder, onChange: e => emit(e.target.value),
    style: { minWidth: 220, minHeight: 32, borderRadius: 8, border: '1px solid var(--dsw-alias-border-l2)', background: 'var(--dsw-alias-bg-layer-1)', color: 'var(--dsw-alias-label-primary)', padding: '6px 12px' } })
}

// ── App root ─────────────────────────────────────────────────────────────

function SkillsPage({ t, onClose, embedded }) {
  const [base, setBase] = useState({ sources: [], market: [], installed: [] })
  const [executors, setExecutors] = useState([])
  const [tab, setTab] = useState('executors')
  const [executorView, setExecutorView] = useState('cards')
  const [filterExecutor, setFilterExecutor] = useState('all')
  const [sourceFilter, setSourceFilter] = useState('all')
  const [marketSettingsOpen, setMarketSettingsOpen] = useState(false)
  const [executorSettingsOpen, setExecutorSettingsOpen] = useState(false)
  const [shareParams, setShareParams] = useState(null)
  const [marketToast, setMarketToast] = useState(null)
  const [marketView, setMarketView] = useState('cards')
  const [marketDrill, setMarketDrill] = useState(null)
  const [searchMarketDrill, setSearchMarketDrill] = useState('')
  const [searchMarketAll, setSearchMarketAll] = useState('')
  const [searchExec, setSearchExec] = useState('')
  const [searchDrill, setSearchDrill] = useState('')
  const [searchAll, setSearchAll] = useState('')
  const [sortBy, setSortBy] = useState('default')
  const [sel, setSel] = useState(null)
  const [tick, forceTick] = useState(0)
  const rootRef = useRef(null)

  // Two data planes with very different costs: the executor summary is a
  // fast (~0.2s) count scan, while GET / walks the whole market collection
  // (~2.3s). Load the summary eagerly and the market set lazily — only when
  // a tab that needs it is opened, and re-fetch it after mutations.
  const [baseStale, setBaseStale] = useState(true)
  const [baseLoading, setBaseLoading] = useState(false)
  // summary 合并刷新：新行/消失行随 fresh 集合走；计数没变且非共享池的行保留
  // 已加载的 skills（避免每次刷新都清空钻取缓存引发整轮重拉——全量视图 20+
  // 个来源）。计数变了或共享池行（linkedBy 反向链接不进计数）丢掉 skills，
  // 由钻取/全量 effect 按需重拉。
  const reloadExecutors = () => {
    getJson(API + '/executors?mode=summary').then(d => setExecutors(prev => {
      const prevByKey = new Map(prev.map(r => [r.key, r]))
      return (d.executors || []).map(r => {
        const old = prevByKey.get(r.key)
        if (old && Array.isArray(old.skills) && old.skillCount === r.skillCount && !r.isPool && !old.isPool) {
          return { ...r, skills: old.skills }
        }
        return r
      })
    })).catch(() => {})
  }
  // 定点失效：让指定来源行的 skills 缓存作废（可见行由 effect 自动重拉，
  // 不可见行等进入时再拉）。用于安装/删除/迁移/恢复/批量删链接之后。
  const staleRows = (keys) => {
    const set = new Set((keys || []).filter(Boolean))
    if (set.size === 0) return
    setExecutors(rows => rows.map(r => set.has(r.key) && Array.isArray(r.skills) ? { ...r, skills: undefined } : r))
  }
  const reloadBase = () => {
    setBaseStale(false)
    setBaseLoading(true)
    getJson(API).then(setBase).catch(() => {}).finally(() => setBaseLoading(false))
  }
  // Install/delete only flips one row's `installed` flag, so patch that row in place
  // instead of re-walking the whole 6k+ market (GET / takes ~2.3s). A stale flag is
  // still set so the next visit to the market tab reconciles with the server.
  const markMarketInstalled = (name, on) => {
    setBase(prev => {
      if (!prev) return prev
      const market = patchMarketInstalled(prev.market, name, on)
      return market === prev.market ? prev : { ...prev, market }
    })
  }
  useEffect(reloadExecutors, [])
  useEffect(() => {
    if (tab === 'market' && baseStale) reloadBase()
  }, [tab, baseStale])

  // Load full lists for one executor on demand
  useEffect(() => {
    if (filterExecutor === 'all') return
    const row = executors.find(x => x.key === filterExecutor)
    if (!row || Array.isArray(row.skills)) return
    let alive = true
    getJson(API + '/executors?executor=' + encodeURIComponent(filterExecutor))
      .then(d => { if (alive) setExecutors(rows => rows.map(r => r.key === d.executor.key ? d.executor : r)) })
      .catch(() => {})
    return () => { alive = false }
  }, [filterExecutor, executors])

  // Load all catalogs when entering the flat all-skills view
  useEffect(() => {
    if (!(tab === 'executors' && executorView === 'all')) return
    const targets = executors.filter(x => x.dirExists && !Array.isArray(x.skills))
    targets.forEach(row => {
      getJson(API + '/executors?executor=' + encodeURIComponent(row.key))
        .then(d => setExecutors(rows => rows.map(r => r.key === d.executor.key ? d.executor : r)))
        .catch(() => {})
    })
  }, [tab, executorView, executors])

  const row = filterExecutor !== 'all' ? executors.find(x => x.key === filterExecutor) : null
  // key → 显示名映射：卡片反向链接头像用 label 派生渐变与首字母
  const executorLabels = {}
  for (const r of executors) executorLabels[r.key] = r.label

  const openDetail = (s, executorKey) => setSel({ name: s.name, executorKey })
  const openShare = (row, s) => {
    const skillName = shortName(s.name)
    const dir = s.__dir || (row && row.dir ? row.dir + (s.relPath ? '/' + s.relPath : '/' + skillName) : '')
    if (!dir) return
    setShareParams({
      skillName,
      version: s.version || '',
      resourceDir: dir,
      remotePath: row && row.key && row.key !== 'dsh' && row.key !== '@market'
        ? `skills/${row.key}/${skillName}/`
        : `skills/${skillName}/`,
    })
  }
  const [pendingDelete, setPendingDelete] = useState(null)
  const [linkerList, setLinkerList] = useState(null) // { name, linkedBy } — 链接来源弹窗
  const [pendingInstallTo, setPendingInstallTo] = useState(null) // { name, from } — 安装到其他执行器
  const [toastText, setToastText] = useState(null)
  const doPendingDelete = async () => {
    if (!pendingDelete) return
    const ok = await quickDelete(t, pendingDelete.executor, pendingDelete.name)
    setPendingDelete(null)
    if (!ok) return
    setToastText(t('movedToTrash'))
    setTimeout(() => setToastText(null), 2600)
    reloadExecutors()
    staleRows([pendingDelete.executor || 'dsh'])
    markMarketInstalled(pendingDelete.name, false)
    setBaseStale(true)
  }

  let body = null
  try {
  if (tab === 'executors') {
    if (filterExecutor !== 'all') {
      body = h(DrillInView, { row, searchText: searchDrill, sortBy, t, executorLabels,
        // 池卡片上的反向链接行：弹出链接来源列表（多选批量删链接）
        onOpenLinker: (s) => setLinkerList({ name: s.name, linkedBy: s.linkedBy }),
        onSearch: setSearchDrill, onSort: setSortBy, onShare: openShare,
        onBack: () => { setFilterExecutor('all'); setSearchDrill('') },
        onOpen: s => openDetail(s, row?.key),
        onInstall: (r, name) => setPendingInstallTo({ name, from: r && r.key && r.key !== '@market' ? r.key : null }),
        onDelete: (r, name) => setPendingDelete({ executor: r.key, name }),
        onToggleVisible: (r, name, modelInvocable) => {
          fetch(API + '/invocation', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, modelInvocable }) })
            .then(() => getJson(API + '/executors?executor=' + encodeURIComponent(r.key))
              .then(d => setExecutors(rows => rows.map(x => x.key === d.executor.key ? d.executor : x))))
            .catch(() => {})
        } })
    } else if (executorView === 'all') {
      body = h(AllSkillsView, { executors, searchText: searchAll, sourceFilter, sortBy, t,
        onSearch: setSearchAll, onSort: setSortBy, onShare: openShare,
        onFilter: v => { setSourceFilter(v); if (v !== 'all') { setFilterExecutor(v); setSearchAll(''); setSearchExec('') } },
        onBack: () => setExecutorView('cards'),
        onOpen: s => { const owner = executors.find(x => x.dirExists && Array.isArray(x.skills) && x.skills.some(k => k.name === s.name)); openDetail(s, owner ? owner.key : sourceFilter !== 'all' ? sourceFilter : 'dsh') },
        onInstall: (r, name) => setPendingInstallTo({ name, from: r && r.key && r.key !== '@market' ? r.key : null }),
        onDelete: (r, name) => setPendingDelete({ executor: r.key, name }),
        onToggleVisible: (r, name, modelInvocable) => {
          fetch(API + '/invocation', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, modelInvocable }) })
            .then(() => getJson(API + '/executors?executor=' + encodeURIComponent(r.key))
              .then(d => setExecutors(rows => rows.map(x => x.key === d.executor.key ? d.executor : x))))
            .catch(() => {})
        } })
    } else {
      body = h(CardsView, { executors, t,
        onEnter: key => { setFilterExecutor(key); setSearchDrill('') },
        onBrowseAll: () => setExecutorView('all'),
        onOpenSettings: () => setExecutorSettingsOpen(true) })
    }
  } else if (tab === 'trash') {
    body = h(TrashView, { t,
      onToast: (text) => { setMarketToast(text); setTimeout(() => setMarketToast(null), 3000) },
      onChanged: (executorKey) => { reloadExecutors(); staleRows([executorKey]); setBaseStale(true) } })
  } else {
    // Market tab mirrors the executors tab: source cards by default, a flat
    // all-skills view on demand, and per-source drill-in with a scoped filter.
    const allMarket = base.market || []
    const lowerAll = searchMarketAll.toLowerCase()
    const mkRow = (src) => ({ key: '@market', label: splitSource(src), readOnly: false, deletable: false })
    if (baseLoading && !allMarket.length) {
      body = h(Spinner, { label: t('marketLoading') })
    } else if (marketDrill !== null) {
      let sk = allMarket.filter(s => s.source === marketDrill)
      const l = searchMarketDrill.toLowerCase()
      if (l) sk = sk.filter(s => matchSkill({ ...s, name: s.shortName || s.name }, l))
      sk = sortSkills(sk, sortBy)
      body = [
        h('div', { className: 'sk-head' },
          h(ButtonLite, { onClick: () => { setMarketDrill(null); setSearchMarketDrill('') } }, t('backSources')),
          h('span', { className: 'sk-title' }, marketDrill),
          h('span', { className: 'sk-tag' }, `${sk.length} ${t('skillsSuffix')}`),
          h(InputBox, { value: searchMarketDrill, placeholder: t('filterWithin', { label: marketDrill }), onSearch: setSearchMarketDrill }),
          SortSelect({ value: sortBy, onChange: setSortBy, t })),
        sk.length
          ? h(PagedGrid, { key: 'md' + marketDrill + sortBy, items: sk, t,
              render: s => h(SkillCard, { key: s.name, row: mkRow(s.source), s: mkCard(s), t,
                onOpen: item => openDetail({ name: item.installName || item.name }, null),
                onInstall: (_r, name) => setPendingInstallTo({ name, from: null }),
                onDelete: () => {} }) })
          : h(Empty, null, t('emptySearch')),
      ]
    } else if (marketView === 'all') {
      const sk = sortSkills(lowerAll ? allMarket.filter(s => matchSkill({ ...s, name: s.shortName || s.name }, lowerAll)) : allMarket, sortBy)
      body = [
        h('div', { className: 'sk-head' },
          h(ButtonLite, { onClick: () => { setMarketView('cards'); setSearchMarketAll('') } }, t('backMarketCards')),
          h('span', { className: 'sk-title' }, t('allMarketTitle')),
          h(InputBox, { value: searchMarketAll, placeholder: t('searchAll'), onSearch: setSearchMarketAll }),
          SortSelect({ value: sortBy, onChange: setSortBy, t }),
          h('span', { className: 'spacer' }),
          h(Tag, null, `${sk.length} ${t('skillsSuffix')}`)),
        sk.length
          ? h(PagedGrid, { key: 'ma' + sortBy, items: sk, t,
              render: s => h(SkillCard, { key: s.name, row: mkRow(s.source), s: mkCard(s), t,
                onOpen: item => openDetail({ name: item.installName || item.name }, null),
                onInstall: (_r, name) => setPendingInstallTo({ name, from: null }),
                onDelete: () => {} }) })
          : h(Empty, null, t('emptySearch')),
      ]
    } else {
      body = [
        h('div', { className: 'sk-toolbar' },
          h('span', { className: 'sk-hint' }, t('marketCardsHint')),
          h('span', { className: 'spacer' }),
          h(P.Button, { variant: 'primary', size: 'sm', onClick: () => setMarketView('all') }, `${t('browseAllMarket')} (${allMarket.length})`),
          h('span', { style: { width: 6 } }),
          h(ButtonLite, { onClick: () => setMarketSettingsOpen(true), title: t('marketSettings') }, t('marketSettings'))),
        base.sources.length
          ? h('div', { className: 'sk-src' }, base.sources.map(src =>
              h('div', { key: src.source, className: 'sk-card', role: 'button', tabIndex: 0,
                onClick: () => { setMarketDrill(src.source); setSearchMarketDrill('') } },
                h('div', { className: 'sk-head' },
                  h(Avatar, { name: src.displayName || src.source, square: true, size: 40 }),
                  h('span', { className: 'sk-title' }, src.displayName || src.source)),
                h('div', { className: 'sk-countline' },
                  h('span', { className: 'sk-count' }, src.skills), ' ' + t('skillsSuffix')))))
          : h(Empty, null, t('emptySearch')),
      ]
    }
  }
  } catch (renderErr) {
    ;(globalThis.__skErrors = globalThis.__skErrors || []).push('body: ' + (renderErr && renderErr.message))
    body = h('div', { className: 'sk-empty', style: { color: 'var(--dsw-alias-state-error-primary)' } },
      '\u26A0\uFE0F ' + String((renderErr && renderErr.message) || renderErr))
  }

  return h('div', { className: 'sk-page' + (embedded ? '' : ' sk-overlay'), ref: rootRef },
    !embedded && h('div', { className: 'sk-head' },
      h('span', { className: 'sk-title', style: { fontSize: 16 } }, t('title')),
      h('span', { className: 'spacer' }),
      h(ButtonLite, { onClick: () => onClose && onClose() }, t('close'))),
    h('div', { className: 'sk-tabs' }, ['executors', 'market', 'trash'].map(key =>
      h('button', { key, className: 'sk-tabpill' + (tab === key ? ' on' : ''), style: pillStyle(tab === key),
        onClick: () => { setTab(key); setFilterExecutor('all'); setExecutorView('cards'); setSearchExec(''); setSearchDrill(''); setSearchAll(''); setMarketView('cards'); setMarketDrill(null); setSearchMarketDrill(''); setSearchMarketAll(''); setSortBy('default') } }, t('tab' + key[0].toUpperCase() + key.slice(1))))),
    h('div', { className: 'sk-body' }, body),
    sel && h(DetailModal, { sel, executors, t,
      onClose: () => setSel(null),
      onInstallTo: (name, executorKey) => setPendingInstallTo({ name, from: executorKey || null }),
      onDeleted: (name, executorKey) => { setSel(null); setToastText(t('movedToTrash')); setTimeout(() => setToastText(null), 2600); reloadExecutors(); staleRows([executorKey || 'dsh']); markMarketInstalled(name, false); setBaseStale(true) },
      onMigrated: (name, migrated) => {
        setToastText(t('migratedToast')); setTimeout(() => setToastText(null), 2600)
        reloadExecutors()
        // 失效来源行（技能变链接）+ 池行（新增实体，带反向链接）；池行 key 按目录路径匹配
        const poolKey = migrated && executors.find(r => r.dir === migrated.poolDir)?.key
        staleRows([migrated && migrated.executor, poolKey])
      } }),
    shareParams && h(ShareSkillDialog, {
      t, params: shareParams, onClose: () => setShareParams(null),
      onToast: (text) => { setMarketToast(text); setTimeout(() => setMarketToast(null), 3000) },
    }),
    marketSettingsOpen && h(MarketSettingsDialog, {
      t,
      onClose: () => setMarketSettingsOpen(false),
      onToast: (text) => { setMarketToast(text); setTimeout(() => setMarketToast(null), 3000) },
      onSynced: () => { setBaseStale(true) },
    }),
    executorSettingsOpen && h(ExecutorSettingsDialog, {
      t,
      onClose: () => setExecutorSettingsOpen(false),
      onToast: (text) => { setMarketToast(text); setTimeout(() => setMarketToast(null), 3000) },
      onChanged: () => reloadExecutors(),
    }),
    marketToast && h(InToast, { text: marketToast }),
    linkerList && h(LinkedByDialog, { t, skill: linkerList, executorLabels,
      onRefreshCandidates: reloadExecutors,
      onClose: () => setLinkerList(null),
      onToast: (text) => { setMarketToast(text); setTimeout(() => setMarketToast(null), 3000) },
      onChanged: (doneKeys) => {
        // 链接删除后池行 linkedBy 与链接来源行都变：定点失效（计数多半不变）
        staleRows([...(doneKeys || []), filterExecutor !== 'all' ? filterExecutor : null])
      } }),
    pendingInstallTo && h(InstallToDialog, { t, name: pendingInstallTo.name, from: pendingInstallTo.from, executors,
      onRefreshCandidates: reloadExecutors,
      onClose: () => setPendingInstallTo(null),
      onToast: (text) => { setMarketToast(text); setTimeout(() => setMarketToast(null), 3000) },
      onChanged: (okKeys) => {
        reloadExecutors()
        staleRows(okKeys) // 目标执行器的技能列表作废重拉（头像排/新卡片即时出现）
        // 装进 dsh 库才算「已安装」徽标；详情弹窗若开着，换个引用逼它重拉
        if (Array.isArray(okKeys) && okKeys.includes('dsh')) {
          markMarketInstalled(pendingInstallTo.name, true)
          setBaseStale(true)
          setSel(s => (s ? { ...s } : s))
        }
      } }),
    toastText && h(InToast, { text: toastText }),
    pendingDelete && h(SkDialog, {
      title: t('deleteTitle'),
      onClose: () => setPendingDelete(null),
      footer: [
        h(ButtonLite, { onClick: () => setPendingDelete(null) }, t('cancel')),
        h(ButtonLite, { primary: true, danger: true, onClick: doPendingDelete }, t('deleteBtn')),
      ],
    }, h('div', { className: 'sk-hint' }, t('deleteConfirm', {
      name: pendingDelete.name,
      where: pendingDelete.executor === 'dsh' || !pendingDelete.executor ? t('whereDsh') : ((executors.find(x => x.key === pendingDelete.executor) || {}).label || pendingDelete.executor),
    }))))
  }

function splitSource(source) { return source.split('/')[0] || source }
/** Market rows carry the full repo path in .name; cards display the short
 *  name but install/detail must POST the full one. */
function mkCard(s) { return { ...s, name: s.shortName || s.name, installName: s.name } }
function selectStyle() {
  return { minHeight: 30, borderRadius: 8, border: '1px solid var(--dsw-alias-border-l2)', background: 'var(--dsw-alias-specific-input-major, var(--dsw-alias-bg-layer-1))', color: 'var(--dsw-alias-label-primary)', padding: '4px 10px' }
}
function pillStyle(on) {
  return {
    padding: '6px 14px', borderRadius: 999, cursor: 'pointer', fontSize: 13.5, fontWeight: on ? 600 : 400,
    border: '1px solid ' + (on ? 'var(--dsw-alias-brand-primary,var(--dsw-alias-state-business-primary))' : 'transparent'),
    background: on ? 'var(--dsw-alias-bg-layer-2)' : 'transparent',
    color: on ? 'var(--dsw-alias-label-primary)' : 'var(--dsw-alias-label-secondary)',
  }
}

async function quickDelete(t, executor, name, done) {
  try {
    const body = { name }
    if (executor) body.executor = executor
    const r = await fetch(API, { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || 'HTTP ' + r.status)
    if (typeof done === 'function') done()
    return true
  } catch (e) { alert(t('operationFailed') + ': ' + e.message); return false }
}

// ── Slot entries ─────────────────────────────────────────────────────────

/** Jump to the run's conversation: open() is best-effort (it may reject
 *  after the selection lands). */
function openRunSession(sessionId) {
  try {
    const svc = sessionsSvc()
    if (svc && typeof svc.open === 'function') svc.open(sessionId)
  } catch {}
  return true
}

/** Settings section slot entry: render the page directly in the host tree. */
function SettingsSlotComponent(props) {
  useEffect(ensureStyles, [])
  return h(SkillsPage, { t: props.__t, embedded: true })
}

// ── Plugin plane contract ────────────────────────────────────────────────

const CLIENT_NAME = '@weibaohui/skills-management'

module.exports = {
  name: CLIENT_NAME,
  inject: ['slots', 'locale'],
  __internals: { NS, ZH, EN, matchSkill, formatSize, formatTime, usageText, markdownLabels, sortSkills, gradient, shortName, isInstalledRow, patchMarketInstalled, openTriggerSource, insertComposerText, insertViaInputActions, fetchSkillCandidates },
  /** Test/host helper: mount a standalone page into any container. */
  __boot(container, opts = {}) {
    ensureStyles()
    let t = opts.t || ((key, vars) => {
      let out = EN[key] ?? key
      if (vars) for (const [k, v] of Object.entries(vars)) out = out.split('{' + k + '}').join(String(v))
      return out
    })
    try {
      if (!opts.t && globalThis.document && !(container.ownerDocument !== document)) { /* noop */ }
    } catch {}
    const root = require('react-dom/client').createRoot(container)
    root.render(h(SkillsPage, { t, embedded: !!opts.embedded }))
    return root
  },
  apply(ctx) {
    // Sessions face for 打开对话: dynamic inject per the ui-commands
    // precedent (scope.sessions). Static inject must NOT list services —
    // that stalls activation; root-level slot entries get no standard kit.
    try {
      if (typeof ctx.inject === 'function') {
        ctx.inject(['sessions'], (scope) => {
          const svc = scope && scope.sessions
          if (svc && typeof svc.open === 'function') sessionsApi = svc
        })
        // dsh 0.1.7+: sessions.open() 被移除，会话导航改走
        // uiWorkspace.openSession()。归一成 { open(id) } 面孔，调用点不变。
        ctx.inject(['uiWorkspace'], (scope) => {
          const svc = scope && scope.uiWorkspace
          if (svc && typeof svc.openSession === 'function' && !sessionsApi) {
            sessionsApi = { open: (id) => svc.openSession(id) }
          }
        })
      }
    } catch {}
    // Composer services (inputTriggers + sessions) for the 技能 button;
    // absence hides the button only.
    try {
      if (typeof ctx.inject === 'function') {
        ctx.inject(['inputTriggers', 'sessions'], (scope) => { composerScope = scope })
      }
    } catch {}
    // Picker skill catalog (host skill registry, ui-skill 同源).
    // 0.1.5+: subpath inject `remote.skills` (just `remote` is not enough —
    // cordis guards child paths against undeclared inject). Older cores fall
    // back to `connection.api.skills`. Absence keeps the button's fallback
    // to the host slash menu.
    try {
      if (typeof ctx.inject === 'function') {
        ctx.inject(['remote', 'remote.skills'], (scope) => {
          remoteSkillsApi = scope && scope.remote && scope.remote.skills
        })
      }
    } catch {}
    try {
      if (typeof ctx.inject === 'function') {
        ctx.inject(['connection'], (scope) => { connectionApi = scope && scope.connection })
      }
    } catch {}
    // Locale service is optional at boot order — degrade to EN until present
    let t = (key, vars) => {
      let out = EN[key] ?? key
      if (vars) for (const [k, v] of Object.entries(vars)) out = out.split('{' + k + '}').join(String(v))
      return out
    }
    try {
      if (ctx.locale && typeof ctx.locale.register === 'function') {
        ctx.locale.register(NS, 'zh', ZH)
        ctx.locale.register(NS, 'en', EN)
        const bound = typeof ctx.locale.bind === 'function' ? ctx.locale.bind(NS) : null
        if (bound) {
          t = (key, vars) => {
            let out = bound(key) || key
            if (vars) for (const [k, v] of Object.entries(vars)) out = out.split('{' + k + '}').join(String(v))
            return out
          }
          globalThis.__skillsLocaleLive = true
        }
      }
    } catch (e) { try { console.error('[skills-management] locale init:', e) } catch {} }
    ctx.effect(() => {
      try {
      ctx.slots.inject('settings.section', () => ctx.slots.register({
        name: 'settings.section',
        id: CLIENT_NAME,
        order: 90,
        locale: NS,
        // resolveSlotLabel 调用 label() 不传参;官方模式是自带绑定翻译的闭包
        label: () => t('title'),
        inject: () => ({}),
      }, function SettingsSectionSlot() {
        return h(SettingsSlotComponent, { __t: t })
      }))
      } catch (e) { (globalThis.__skErrors = globalThis.__skErrors || []).push('settings:' + (e && e.message)); throw e }
    }, 'skills-management: settings section')
    ctx.effect(() => {
      try {
      ctx.slots.inject('conversation.input.left', () => ctx.slots.register({
        name: 'conversation.input.left',
        id: CLIENT_NAME,
        order: 60,
        locale: NS,
        label: () => t('pickSkill'),
        inject: () => ({ t }),
      }, function SkillButtonSlot(apiProps) {
        return h(ComposerButtonSlot, {
          __t: t, label: t('pickSkill'), title: t('pickSkillTitle'),
          source: 'skill', sessionId: apiProps && apiProps.sessionId, input: apiProps && apiProps.input,
          inputActions: apiProps && apiProps.inputActions,
        })
      }))
      } catch (e) { (globalThis.__skErrors = globalThis.__skErrors || []).push('input.left:' + (e && e.message)); throw e }
    }, 'skills-management: input left button')
  },
}

/** Lucide `wrench`（ISC）内联 SVG：fill none / stroke currentColor，明暗主题
 *  自动跟随；尺寸交给 .sk-chip svg（13px），与工具行其它线性图标同款描边。 */
function IconWrench() {
  return h('svg', {
    viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor',
    'stroke-width': 2, 'stroke-linecap': 'round', 'stroke-linejoin': 'round',
    'aria-hidden': 'true',
  }, h('path', { d: 'M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z' }))
}

/** Composer tool-row button: 扳手图标+文字 chip（无边框静默样式，与宿主工具行
 *  控件一致），点击在按钮上方打开自带搜索的
 *  技能 picker 浮层（候选 = 宿主技能注册表，ui-skill 同源）；pick 经
 *  slash/input-insert-text 写入 `/<name> `。浮层背板盖住按钮以外的区域，
 *  再点一次按钮会先落在背板上——天然形成开关切换。
 *  目录来源（remote.skills / connection.api）都缺席时回退旧的 toggleSource
 *  宿主菜单；inputTriggers/sessions 缺席时按钮隐藏（与旧行为一致）。 */
function ComposerButtonSlot(props) {
  useEffect(ensureStyles, [])
  const [picker, setPicker] = useState(null) // {left, top} 锚点快照；null = 关闭
  const [rows, setRows] = useState(null)     // null = 加载中
  const btnRef = useRef(null)
  const liveInput = useRef(props.input)
  liveInput.current = props.input
  const ready = !!(composerScope && composerScope.inputTriggers && composerScope.sessions && props.sessionId)
  if (!ready) return null
  const close = () => setPicker(null)
  const open = () => {
    // 目录来源缺席 → 退回宿主斜杠菜单（无搜索，但按钮不消失）
    if (!remoteSkillsApi && !connectionApi) { openTriggerSource(composerScope, props.sessionId, liveInput.current, props.source); return }
    let anchor = { left: 16, top: 160 }
    try { if (btnRef.current) anchor = btnRef.current.getBoundingClientRect() } catch {}
    setPicker({ left: anchor.left, top: anchor.top })
    setRows(null)
    fetchSkillCandidates({ remoteSkills: remoteSkillsApi, connection: connectionApi }, composerScope.sessions, props.sessionId)
      .then((list) => setRows(Array.isArray(list) ? list : []))
      .catch(() => setRows([]))
  }
  const pick = (row) => {
    const text = `/${row.name} `
    // dsh 0.2.x: capture the span at pick time via the slot's inputActions;
    // ≤0.1.x hosts (no inputActions, live `input` prop) fall back to the
    // scoped-event splice with the prop snapshot.
    const ok = insertViaInputActions(props.inputActions, text)
      || insertComposerText(composerScope, props.sessionId, liveInput.current, text)
    if (!ok) {
      try { console.warn('[skills-management] draft insert failed for', row.name) } catch {}
    }
    close()
    refocusComposer()
  }
  const popover = picker !== null && RDP && typeof RDP.createPortal === 'function'
    ? RDP.createPortal(h(SkillPicker, { t: props.__t, anchor: picker, rows, onClose: close, onPick: pick }), document.body)
    : null
  return h('button', {
    className: 'sk-chip',
    ref: btnRef,
    title: props.title || props.label,
    'aria-haspopup': 'dialog',
    'aria-expanded': picker !== null,
    onClick: open,
  }, h(IconWrench), props.label, popover)
}
