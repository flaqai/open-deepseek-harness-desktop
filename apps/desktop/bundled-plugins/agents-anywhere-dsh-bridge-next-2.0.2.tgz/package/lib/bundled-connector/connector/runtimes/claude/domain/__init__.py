"""Claude runtime domain helpers."""
